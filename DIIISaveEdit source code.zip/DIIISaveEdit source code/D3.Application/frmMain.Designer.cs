#region Copyright

//  Copyright � 2013 - 2017 AWP ENT LLC (xx_CKY_xx at hotmail dot com)
//  
//   This(software is provided) 'as-is', without any express or implied
//   warranty. Under no circumstances will the authors be held liable for any damages encountered 
//   from the use of this software.
//  
//   Permission is granted to anyone to use this software for any purpose
//   excluding commercial applications, or to alter it and redistribute it
//   freely, subject to the following restrictions:
//  
//   1. The origin of this software must not be misrepresented; you must not
//     claim that you wrote the original software. If you use this software
//     in a product, an acknowledgment in the product documentation is required.
//  
//   2. Altered source versions must be plainly marked as such, and must not
//      be misrepresented as being the original software.
//  
//   3. This notice may not be removed or altered from any source distribution in any way.

#endregion


namespace D3.Application
{
    /// <summary>
    /// form designer
    /// </summary>
    public partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.backgroundWorker = new System.ComponentModel.BackgroundWorker();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.MnuReplace = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.LoginMnu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.saveMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.exitMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.patitionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LoginMainMnu = new System.Windows.Forms.ToolStripMenuItem();
            this.mainTab = new MTC.ManagedTabControl();
            this.HeartBeat = new System.Windows.Forms.Timer(this.components);
            this.contextMenuStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // folderBrowserDialog1
            // 
            this.folderBrowserDialog1.RootFolder = System.Environment.SpecialFolder.MyComputer;
            this.folderBrowserDialog1.ShowNewFolderButton = false;
            // 
            // backgroundWorker
            // 
            this.backgroundWorker.WorkerReportsProgress = true;
            this.backgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker_DoWork);
            this.backgroundWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.backgroundWorker_ProgressChanged);
            this.backgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker_RunWorkerCompleted);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuReplace});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            resources.ApplyResources(this.contextMenuStrip1, "contextMenuStrip1");
            // 
            // MnuReplace
            // 
            this.MnuReplace.Name = "MnuReplace";
            resources.ApplyResources(this.MnuReplace, "MnuReplace");
            // 
            // menuStrip1
            // 
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileMenuItem,
            this.patitionToolStripMenuItem,
            this.LoginMainMnu});
            this.menuStrip1.Name = "menuStrip1";
            // 
            // fileMenuItem
            // 
            this.fileMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.fileMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openMenuItem,
            this.toolStripSeparator2,
            this.LoginMnu,
            this.toolStripSeparator1,
            this.saveMenuItem,
            this.toolStripSeparator3,
            this.exitMenuItem});
            this.fileMenuItem.ForeColor = System.Drawing.Color.White;
            this.fileMenuItem.Name = "fileMenuItem";
            resources.ApplyResources(this.fileMenuItem, "fileMenuItem");
            // 
            // openMenuItem
            // 
            this.openMenuItem.Name = "openMenuItem";
            resources.ApplyResources(this.openMenuItem, "openMenuItem");
            this.openMenuItem.Click += new System.EventHandler(this.OpenMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            resources.ApplyResources(this.toolStripSeparator2, "toolStripSeparator2");
            // 
            // LoginMnu
            // 
            this.LoginMnu.Name = "LoginMnu";
            resources.ApplyResources(this.LoginMnu, "LoginMnu");
            this.LoginMnu.Click += new System.EventHandler(this.LoginMnu_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            resources.ApplyResources(this.toolStripSeparator1, "toolStripSeparator1");
            // 
            // saveMenuItem
            // 
            this.saveMenuItem.Name = "saveMenuItem";
            resources.ApplyResources(this.saveMenuItem, "saveMenuItem");
            this.saveMenuItem.Click += new System.EventHandler(this.SaveMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            resources.ApplyResources(this.toolStripSeparator3, "toolStripSeparator3");
            // 
            // exitMenuItem
            // 
            this.exitMenuItem.Name = "exitMenuItem";
            resources.ApplyResources(this.exitMenuItem, "exitMenuItem");
            this.exitMenuItem.Click += new System.EventHandler(this.ExitMenuItem_Click);
            // 
            // patitionToolStripMenuItem
            // 
            this.patitionToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.patitionToolStripMenuItem.Name = "patitionToolStripMenuItem";
            resources.ApplyResources(this.patitionToolStripMenuItem, "patitionToolStripMenuItem");
            this.patitionToolStripMenuItem.Click += new System.EventHandler(this.patitionToolStripMenuItem_Click);
            // 
            // LoginMainMnu
            // 
            this.LoginMainMnu.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.LoginMainMnu.ForeColor = System.Drawing.Color.Red;
            this.LoginMainMnu.Name = "LoginMainMnu";
            resources.ApplyResources(this.LoginMainMnu, "LoginMainMnu");
            this.LoginMainMnu.Tag = "Login";
            this.LoginMainMnu.Click += new System.EventHandler(this.LoginMnu_Click);
            // 
            // mainTab
            // 
            this.mainTab.AllowAutoTabPageDragAndDrop = false;
            this.mainTab.AllowTabPageDragAndDrop = false;
            this.mainTab.AllowTabPagesReorder = false;
            this.mainTab.AutoSelectAddedTabPageAfterAddingIt = false;
            this.mainTab.CloseBoxAlwaysVisible = false;
            this.mainTab.CloseBoxOnEachPageVisible = false;
            this.mainTab.CloseTabOnCloseButtonClick = false;
            resources.ApplyResources(this.mainTab, "mainTab");
            this.mainTab.ForeColor = System.Drawing.Color.White;
            this.mainTab.Name = "mainTab";
            this.mainTab.SelectedTabPageIndex = 0;
            this.mainTab.ShowTabPageToolTip = false;
            this.mainTab.ShowTabPageToolTipAlways = false;
            this.mainTab.TabPageMaxWidth = 250;
            // 
            // HeartBeat
            // 
            this.HeartBeat.Interval = 3600000;
            this.HeartBeat.Tick += new System.EventHandler(this.HeartBeat_Tick);
            // 
            // FrmMain
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.mainTab);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.KeyPreview = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FrmMain";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.contextMenuStrip1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitMenuItem;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.ToolStripMenuItem saveMenuItem;
        private System.ComponentModel.BackgroundWorker backgroundWorker;
        private System.Windows.Forms.Timer timer1;
        private MTC.ManagedTabControl mainTab;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MnuReplace;
        private System.Windows.Forms.ToolStripMenuItem patitionToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem LoginMnu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem LoginMainMnu;
        private System.Windows.Forms.Timer HeartBeat;
    }
}