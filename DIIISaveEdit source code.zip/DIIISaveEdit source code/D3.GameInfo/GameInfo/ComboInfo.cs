#region Copyright

//  Copyright � 2013 - 2017 AWP ENT LLC (xx_CKY_xx at hotmail dot com)
//  
//   This(software is provided) 'as-is', without any express or implied
//   warranty. Under no circumstances will the authors be held liable for any damages encountered 
//   from the use of this software.
//  
//   Permission is granted to anyone to use this software for any purpose
//   excluding commercial applications, or to alter it and redistribute it
//   freely, subject to the following restrictions:
//  
//   1. The origin of this software must not be misrepresented; you must not
//     claim that you wrote the original software. If you use this software
//     in a product, an acknowledgment in the product documentation is required.
//  
//   2. Altered source versions must be plainly marked as such, and must not
//      be misrepresented as being the original software.
//  
//   3. This notice may not be removed or altered from any source distribution in any way.

#endregion

namespace D3.GameInfo
{
    using System.Collections.Generic;
    using System.Drawing;

    public class DyeInfo
    {
        private readonly string _text;
        private readonly int _value;

        public DyeInfo(string text, int value)
        {
            this._text = text;
            this._value = value;
        }

        public string Text
        {
            get { return this._text; }
        }

        public int Value
        {
            get { return this._value; }
        }

        public static Color DyeColor(int index)
        {
            System.Drawing.Color backColor = new System.Drawing.Color();
            switch (index)
            {
                case 1:
                    backColor = System.Drawing.Color.Black;
                    break;
                case 2:
                    backColor = System.Drawing.Color.Red;
                    break;
                case 3:
                    backColor = System.Drawing.Color.White;
                    break;
                case 4:
                    backColor = System.Drawing.Color.Pink;
                    break;
                case 5:
                    backColor = System.Drawing.Color.Purple;
                    break;
                case 6:
                    backColor = System.Drawing.Color.Fuchsia;
                    break;
                case 7:
                    backColor = System.Drawing.Color.Yellow;
                    break;
                case 8:
                    backColor = System.Drawing.Color.Gold;
                    break;
                case 9:
                    backColor = System.Drawing.Color.Orange;
                    break;
                case 10:
                    backColor = System.Drawing.Color.Blue;
                    break;
                case 11:
                    backColor = System.Drawing.Color.LightBlue;
                    break;
                case 12:
                    backColor = System.Drawing.Color.Gray;
                    break;
                case 13:
                    backColor = System.Drawing.Color.DarkSlateGray;
                    break;
                case 14:
                    backColor = System.Drawing.Color.Green;
                    break;
                case 15:
                    backColor = System.Drawing.Color.DarkRed;
                    break;
                case 16:
                    backColor = System.Drawing.Color.LightGreen;
                    break;
                case 17:
                    backColor = System.Drawing.Color.YellowGreen;
                    break;
                case 18:
                    backColor = System.Drawing.Color.SaddleBrown;
                    break;
                case 19:
                    backColor = System.Drawing.Color.SandyBrown;
                    break;
                case 20:
                    backColor = System.Drawing.Color.WhiteSmoke;
                    break;
                default:
                    backColor = System.Drawing.Color.Cyan;
                    break;
            }
            return backColor;
        }
    }

    public class BannerColorInfo
    {
        private readonly uint _value;

        public BannerColorInfo(uint value)
        {
            _value = value;
        }

        public uint Value
        {
            get { return this._value; }
        }

        public static Color BannerColor(uint index)
        {
            System.Drawing.Color backColor = new System.Drawing.Color();
            switch (index)
            {
                case 1379006192:
                    backColor = System.Drawing.Color.FromArgb(102, 153, 204);
                    break;
                case 1632619344:
                    backColor = System.Drawing.Color.Red;
                    break;
                case 1632621400:
                    backColor = System.Drawing.Color.Tan;
                    break;
                case 1797588777:
                    backColor = System.Drawing.Color.FromArgb(25, 25, 112);
                    break;
                case 2045456409:
                    backColor = System.Drawing.Color.ForestGreen;
                    break;
                case 2086128241:
                    backColor = System.Drawing.Color.Orange;
                    break;
                case 2129434669:
                    backColor = System.Drawing.Color.Purple;
                    break;
                case 2298573630:
                    backColor = System.Drawing.Color.YellowGreen;
                    break;
                case 2336264093:
                    backColor = System.Drawing.Color.Blue;
                    break;
                case 2336449672:
                    backColor = System.Drawing.Color.Gray;
                    break;
                case 2336763719:
                    backColor = System.Drawing.Color.Pink;
                    break;
                case 2336902683:
                    backColor = System.Drawing.Color.Teal;
                    break;
                case 2462458609:
                    backColor = System.Drawing.Color.Yellow;
                    break;
                case 2557535182:
                    backColor = System.Drawing.Color.FromArgb(13, 152, 186);
                    break;
                case 3579977098:
                    backColor = System.Drawing.Color.FromArgb(169, 169, 169);
                    break;
                case 3749127283:
                    backColor = System.Drawing.Color.FromArgb(204, 204, 0);
                    break;
                case 3933252926:
                    backColor = System.Drawing.Color.Olive;
                    break;
                case 3948365221:
                    backColor = System.Drawing.Color.DeepPink;
                    break;
                case 4082249298:
                    backColor = System.Drawing.Color.Black;
                    break;
                case 4082473632:
                    backColor = System.Drawing.Color.FromArgb(203, 65, 84);
                    break;
                case 4082480829:
                    backColor = System.Drawing.Color.Brown;
                    break;
                case 4088398950:
                    backColor = System.Drawing.Color.Green;
                    break;
                case 4107019158:
                    backColor = System.Drawing.Color.White;
                    break;
            }
            return backColor;
        }
    }

    public class ItemLevel
    {
        public ItemLevel(string text, int value)
        {
            this.Text = text;
            this.Value = value;
        }

        public string Text { get; private set; }

        public int Value { get; private set; }

        public static Color RarityColor(int index)
        {
            System.Drawing.Color backColor = new System.Drawing.Color();
            switch (index)
            {
                case -2:
                case -1:
                    backColor = System.Drawing.Color.Cyan;
                    break;
                case 0:
                case 1:
                case 2:
                    backColor = System.Drawing.Color.White;
                    break;
                case 3:
                case 4:
                case 5:
                case 10:
                    backColor = System.Drawing.Color.Blue;
                    break;
                case 6:
                case 7:
                case 8:
                    backColor = System.Drawing.Color.Yellow;
                    break;
                case 9:
                    backColor = System.Drawing.Color.Orange;
                    break;
                //case 11:
                //    backColor = System.Drawing.Color.Green;
                //    break;
                //case 12:
                //case 13:
                //case 14:
                //case 15:
                //    backColor = System.Drawing.Color.Gray;
                //    break;
                default:
                    backColor = System.Drawing.Color.Pink;
                    break;
            }
            return backColor;
        }
    }

    public class ItemSlot
    {
        public static Dictionary<int, string> SlotIndex = new Dictionary<int, string>
        {
            {0, "Locker"},
            {272, "Inventory"},
            {288, "Head"},
            {304, "Chest"},
            {320, "Off_Hand"},
            {336, "Main_Hand"},
            {352, "Gloves"},
            {368, "Belt"},
            {384, "Boots"},
            {400, "Shoulders"},
            {416, "Pants"},
            {432, "Wrist"},
            {448, "Ring_2"},
            {464, "Ring_1"},
            {480, "Necklace"},
            {544, "Stash"},
            {560, "gold"},
            {1024, "Socket"},
            {1296, "Follower_Off_Hand"},
            {1312, "Follower_Main_Hand"},
            {1328, "Follower_Relic"},
            {1344, "Follower_Necklace"},
            {1360, "Follower_Ring1"},
            {1376, "Follower_Ring2"}
        };
        public static void Clear()
        {
            SlotIndex.Clear();
            SlotIndex.Add(0, "Locker");
            SlotIndex.Add(272, "Inventory");
            SlotIndex.Add(288, "Head");
            SlotIndex.Add(304, "Chest");
            SlotIndex.Add(320, "Off_Hand");
            SlotIndex.Add(336, "Main_Hand");
            SlotIndex.Add(352, "Gloves");
            SlotIndex.Add(368, "Belt");
            SlotIndex.Add(384, "Boots");
            SlotIndex.Add(400, "Shoulders");
            SlotIndex.Add(416, "Pants");
            SlotIndex.Add(432, "Wrist");
            SlotIndex.Add(448, "Ring_2");
            SlotIndex.Add(464, "Ring_1");
            SlotIndex.Add(480, "Necklace");
            SlotIndex.Add(544, "Stash");
            SlotIndex.Add(560, "gold");
            SlotIndex.Add(1024, "Socket");
            SlotIndex.Add(1296, "Follower_Off_Hand");
            SlotIndex.Add(1312, "Follower_Main_Hand");
            SlotIndex.Add(1328, "Follower_Relic");
            SlotIndex.Add(1344, "Follower_Necklace");
            SlotIndex.Add(1360, "Follower_Ring1");
            SlotIndex.Add(1376, "Follower_Ring2");
        }
    }
    public class Hireing_Class
    {
        public static Dictionary<int, string> SlotIndex = new Dictionary<int, string>
        {
            {0, "Profile"},
            {1, "Templar"},
            {2, "Scoundrel"},
            {3, "Enchantress"}
        };
    }
}