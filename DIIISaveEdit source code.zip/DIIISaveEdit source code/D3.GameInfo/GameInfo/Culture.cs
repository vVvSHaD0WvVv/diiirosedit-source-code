#region Copyright

//  Copyright � 2013 - 2017 AWP ENT LLC (xx_CKY_xx at hotmail dot com)
//  
//   This(software is provided) 'as-is', without any express or implied
//   warranty. Under no circumstances will the authors be held liable for any damages encountered 
//   from the use of this software.
//  
//   Permission is granted to anyone to use this software for any purpose
//   excluding commercial applications, or to alter it and redistribute it
//   freely, subject to the following restrictions:
//  
//   1. The origin of this software must not be misrepresented; you must not
//     claim that you wrote the original software. If you use this software
//     in a product, an acknowledgment in the product documentation is required.
//  
//   2. Altered source versions must be plainly marked as such, and must not
//      be misrepresented as being the original software.
//  
//   3. This notice may not be removed or altered from any source distribution in any way.

#endregion

namespace D3.GameInfo
{
    using System.Globalization;

    public class Culture
    {
        public static string culture
        {
            get { return CultureInfo.CurrentCulture.Name; }
        }

        public static void Getinfo()
        {
            switch (culture)
            {
                case "en": //	English
                case "en-AU": //	English - Australia
                case "en-BZ": //	English - Belize
                case "en-CA": //	English - Canada
                case "en-CB": //	English - Caribbean
                case "en-IE": //	English - Ireland
                case "en-JM": //	English - Jamaica
                case "en-NZ": //	English - New Zealand
                case "en-PH": //	English - Philippines
                case "en-ZA": //	English - South Africa
                case "en-TT": //	English - Trinidad and Tobago
                case "en-GB": //	English - United Kingdom
                case "en-US": //	English - United States
                case "en-ZW": //	English - Zimbabwe
                    CultureEntry.Cultureentry(65001, "EN");
                    break;
                case "zh": //	Chinese
                case "zh-HK": //	Chinese - Hong Kong SAR
                case "zh-MO": //	Chinese - Macau SAR
                case "zh-CN": //	Chinese - China
                case "zh-CHS": //	Chinese (Simplified)
                case "zh-SG": //	Chinese - Singapore
                case "zh-TW": //	Chinese - Taiwan
                case "zh-CHT": //	Chinese (Traditional)
                    CultureEntry.Cultureentry(950, "CN");
                    break;
                case "fr": //   French
                case "fr-BE": //   French - Belgium	0x080C	FRB
                case "fr-CA": //	French - Canada	0x0C0C	FRC
                case "fr-FR": //	French - France	0x040C	 
                case "fr-LU": //	French - Luxembourg	0x140C	FRL
                case "fr-MC": //	French - Monaco	0x180C	 
                case "fr-CH": //	French - Switzerland	0x100C	FRS
                    CultureEntry.Cultureentry(850, "FR");
                    break;
                case "de": //	German
                case "de-AT": //	German - Austria	0x0C07	DEA
                case "de-DE": //	German - Germany	0x0407	 
                case "de-LI": //	German - Liechtenstein	0x1407	DEC
                case "de-LU": //	German - Luxembourg	0x1007	DEL
                case "de-CH": //	German - Switzerland	0x0807	DES
                    CultureEntry.Cultureentry(20106, "DE");
                    break;
                case "pt": //   Portuguese
                case "pt-BR": //	Portuguese - Brazil	0x0416	PTB
                case "pt-PT": //	Portuguese - Portugal	0x0816	
                    CultureEntry.Cultureentry(860, "PT");
                    break;
                case "es-AR": //Spanish - Argentina": //0x2C0A": //ESS
                case "es-BO": //Spanish - Bolivia": //0x400A": //ESB
                case "es-CL": //Spanish - Chile": //0x340A": //ESL
                case "es-CO": //Spanish - Colombia": //0x240A": //ESO
                case "es-CR": //Spanish - Costa Rica": //0x140A": //ESC
                case "es-DO": //Spanish - Dominican Republic": //0x1C0A": //ESD
                case "es-EC": //Spanish - Ecuador": //0x300A": //ESF
                case "es-SV": //Spanish - El Salvador": //0x440A": //ESE
                case "es-GT": //Spanish - Guatemala": //0x100A": //ESG
                case "es-HN": //Spanish - Honduras": //0x480A": //ESH
                case "es-MX": //Spanish - Mexico": //0x080A": //ESM
                case "es-NI": //Spanish - Nicaragua": //0x4C0A": //ESI
                case "es-PA": //Spanish - Panama": //0x180A": //ESA
                case "es-PY": //Spanish - Paraguay": //0x3C0A": //ESZ
                case "es-PE": //Spanish - Peru": //0x280A": //ESR
                case "es-PR": //Spanish - Puerto Rico": //0x500A": //ES
                case "es-ES": //Spanish - Spain": //0x0C0A": // 
                case "es-UY": //Spanish - Uruguay": //0x380A": //ESY
                case "es-VE": //Spanish - Venezuela": //0x200A": //ESV
                    CultureEntry.Cultureentry(65001, "ES");
                    break;
                default:
                    CultureEntry.Cultureentry(65001, "EN");
                    break;
            }
        }
        //public static string replaceGermanUmlauts(string t)
        //{
        //    t = t.Replace("�", "ae").Replace("�", "oe").Replace("�", "ue").Replace("�", "Ae").Replace("�", "Oe").Replace("�", "Ue").Replace("�", "ss");
        //    return t;
        //}
    }

    public static class CultureEntry
    {
        public static void Cultureentry(int encode, string file)
        {
            Encode = encode;
            Sfile = file;
        }

        public static int Encode { get; set; }
        public static string Sfile { get; set; }
    }
}

/* 
Info.CodePage      Info.Name                    Info.DisplayName
37                 IBM037                       IBM EBCDIC (US-Canada)       
437                IBM437                       OEM United States            
500                IBM500                       IBM EBCDIC (International)    
708                ASMO-708                     Arabic (ASMO 708)            
720                DOS-720                      Arabic (DOS)                 
737                ibm737                       Greek (DOS)                  
775                ibm775                       Baltic (DOS)                 
850                ibm850                       Western European (DOS)       
852                ibm852                       Central European (DOS)       
855                IBM855                       OEM Cyrillic                 
857                ibm857                       Turkish (DOS)                
858                IBM00858                     OEM Multilingual Latin I     
860                IBM860                       Portuguese (DOS)             
861                ibm861                       Icelandic (DOS)              
862                DOS-862                      Hebrew (DOS)                 
863                IBM863                       French Canadian (DOS)        
864                IBM864                       Arabic (864)                 
865                IBM865                       Nordic (DOS)                 
866                cp866                        Cyrillic (DOS)               
869                ibm869                       Greek, Modern (DOS)          
870                IBM870                       IBM EBCDIC (Multilingual Latin-2)    
874                windows-874                  Thai (Windows)               
875                cp875                        IBM EBCDIC (Greek Modern)    
932                shift_jis                    Japanese (Shift-JIS)         
936                gb2312                       Chinese Simplified (GB2312)    
949                ks_c_5601-1987               Korean                       
950                big5                         Chinese Traditional (Big5)    
1026               IBM1026                      IBM EBCDIC (Turkish Latin-5)    
1047               IBM01047                     IBM Latin-1                  
1140               IBM01140                     IBM EBCDIC (US-Canada-Euro)    
1141               IBM01141                     IBM EBCDIC (Germany-Euro)    
1142               IBM01142                     IBM EBCDIC (Denmark-Norway-Euro)    
1143               IBM01143                     IBM EBCDIC (Finland-Sweden-Euro)    
1144               IBM01144                     IBM EBCDIC (Italy-Euro)      
1145               IBM01145                     IBM EBCDIC (Spain-Euro)      
1146               IBM01146                     IBM EBCDIC (UK-Euro)         
1147               IBM01147                     IBM EBCDIC (France-Euro)     
1148               IBM01148                     IBM EBCDIC (International-Euro)    
1149               IBM01149                     IBM EBCDIC (Icelandic-Euro)    
1200               utf-16                       Unicode                      
1201               unicodeFFFE                  Unicode (Big-Endian)         
1250               windows-1250                 Central European (Windows)    
1251               windows-1251                 Cyrillic (Windows)           
1252               Windows-1252                 Western European (Windows)    
1253               windows-1253                 Greek (Windows)              
1254               windows-1254                 Turkish (Windows)            
1255               windows-1255                 Hebrew (Windows)             
1256               windows-1256                 Arabic (Windows)             
1257               windows-1257                 Baltic (Windows)             
1258               windows-1258                 Vietnamese (Windows)         
1361               Johab                        Korean (Johab)               
10000              macintosh                    Western European (Mac)       
10001              x-mac-japanese               Japanese (Mac)               
10002              x-mac-chinesetrad            Chinese Traditional (Mac)    
10003              x-mac-korean                 Korean (Mac)                 
10004              x-mac-arabic                 Arabic (Mac)                 
10005              x-mac-hebrew                 Hebrew (Mac)                 
10006              x-mac-greek                  Greek (Mac)                  
10007              x-mac-cyrillic               Cyrillic (Mac)               
10008              x-mac-chinesesimp            Chinese Simplified (Mac)     
10010              x-mac-romanian               Romanian (Mac)               
10017              x-mac-ukrainian              Ukrainian (Mac)              
10021              x-mac-thai                   Thai (Mac)                   
10029              x-mac-ce                     Central European (Mac)       
10079              x-mac-icelandic              Icelandic (Mac)              
10081              x-mac-turkish                Turkish (Mac)                
10082              x-mac-croatian               Croatian (Mac)               
12000              utf-32                       Unicode (UTF-32)             
12001              utf-32BE                     Unicode (UTF-32 Big-Endian)    
20000              x-Chinese-CNS                Chinese Traditional (CNS)    
20001              x-cp20001                    TCA Taiwan                   
20002              x-Chinese-Eten               Chinese Traditional (Eten)    
20003              x-cp20003                    IBM5550 Taiwan               
20004              x-cp20004                    TeleText Taiwan              
20005              x-cp20005                    Wang Taiwan                  
20105              x-IA5                        Western European (IA5)       
20106              x-IA5-German                 German (IA5)                 
20107              x-IA5-Swedish                Swedish (IA5)                
20108              x-IA5-Norwegian              Norwegian (IA5)              
20127              us-ascii                     US-ASCII                     
20261              x-cp20261                    T.61                         
20269              x-cp20269                    ISO-6937                     
20273              IBM273                       IBM EBCDIC (Germany)         
20277              IBM277                       IBM EBCDIC (Denmark-Norway)    
20278              IBM278                       IBM EBCDIC (Finland-Sweden)    
20280              IBM280                       IBM EBCDIC (Italy)           
20284              IBM284                       IBM EBCDIC (Spain)           
20285              IBM285                       IBM EBCDIC (UK)              
20290              IBM290                       IBM EBCDIC (Japanese katakana)    
20297              IBM297                       IBM EBCDIC (France)          
20420              IBM420                       IBM EBCDIC (Arabic)          
20423              IBM423                       IBM EBCDIC (Greek)           
20424              IBM424                       IBM EBCDIC (Hebrew)          
20833              x-EBCDIC-KoreanExtended      IBM EBCDIC (Korean Extended)    
20838              IBM-Thai                     IBM EBCDIC (Thai)            
20866              koi8-r                       Cyrillic (KOI8-R)            
20871              IBM871                       IBM EBCDIC (Icelandic)       
20880              IBM880                       IBM EBCDIC (Cyrillic Russian)    
20905              IBM905                       IBM EBCDIC (Turkish)         
20924              IBM00924                     IBM Latin-1                  
20932              EUC-JP                       Japanese (JIS 0208-1990 and 0212-1990)    
20936              x-cp20936                    Chinese Simplified (GB2312-80)    
20949              x-cp20949                    Korean Wansung               
21025              cp1025                       IBM EBCDIC (Cyrillic Serbian-Bulgarian)    
21866              koi8-u                       Cyrillic (KOI8-U)            
28591              iso-8859-1                   Western European (ISO)       
28592              iso-8859-2                   Central European (ISO)       
28593              iso-8859-3                   Latin 3 (ISO)                
28594              iso-8859-4                   Baltic (ISO)                 
28595              iso-8859-5                   Cyrillic (ISO)               
28596              iso-8859-6                   Arabic (ISO)                 
28597              iso-8859-7                   Greek (ISO)                  
28598              iso-8859-8                   Hebrew (ISO-Visual)          
28599              iso-8859-9                   Turkish (ISO)                
28603              iso-8859-13                  Estonian (ISO)               
28605              iso-8859-15                  Latin 9 (ISO)                
29001              x-Europa                     Europa                       
38598              iso-8859-8-i                 Hebrew (ISO-Logical)         
50220              iso-2022-jp                  Japanese (JIS)               
50221              csISO2022JP                  Japanese (JIS-Allow 1 byte Kana)    
50222              iso-2022-jp                  Japanese (JIS-Allow 1 byte Kana - SO/SI)    
50225              iso-2022-kr                  Korean (ISO)                 
50227              x-cp50227                    Chinese Simplified (ISO-2022)    
51932              euc-jp                       Japanese (EUC)               
51936              EUC-CN                       Chinese Simplified (EUC)     
51949              euc-kr                       Korean (EUC)                 
52936              hz-gb-2312                   Chinese Simplified (HZ)      
54936              GB18030                      Chinese Simplified (GB18030)    
57002              x-iscii-de                   ISCII Devanagari             
57003              x-iscii-be                   ISCII Bengali                
57004              x-iscii-ta                   ISCII Tamil                  
57005              x-iscii-te                   ISCII Telugu                 
57006              x-iscii-as                   ISCII Assamese               
57007              x-iscii-or                   ISCII Oriya                  
57008              x-iscii-ka                   ISCII Kannada                
57009              x-iscii-ma                   ISCII Malayalam              
57010              x-iscii-gu                   ISCII Gujarati               
57011              x-iscii-pa                   ISCII Punjabi                
65000              utf-7                        Unicode (UTF-7)              
65001              utf-8                        Unicode (UTF-8)  
  
  
Language    Culture Name	Display Name	Culture Code	ISO 639x Value
af-ZA   	Afrikaans       South Africa     	0x0436      	AFK
sq-AL   Albanian        Albania	            0x041C      	SQI
ar-DZ   	Arabic          Algeria	            0x1401	        ARG
ar-BH	    Arabic          Bahrain             0x3C01	        ARH
ar-EG	Arabic - Egypt	0x0C01	ARE
ar-IQ	Arabic - Iraq	0x0801	ARI
ar-JO	Arabic - Jordan	0x2C01	ARJ
ar-KW	Arabic - Kuwait	0x3401	ARK
ar-LB	Arabic - Lebanon	0x3001	ARB
ar-LY	Arabic - Libya	0x1001	ARL
ar-MA	Arabic - Morocco	0x1801	ARM
ar-OM	Arabic - Oman	0x2001	ARO
ar-QA	Arabic - Qatar	0x4001	ARQ
ar-SA	Arabic - Saudi Arabia	0x0401	ARA
ar-SY	Arabic - Syria	0x2801	ARS
ar-TN	Arabic - Tunisia	0x1C01	ART
ar-AE	Arabic - United Arab Emirates	0x3801	ARU
ar-YE	Arabic - Yemen	0x2401	ARY
hy-AM	Armenian - Armenia	0x042B	 
Cy-az-AZ	Azeri (Cyrillic) - Azerbaijan	0x082C	 
Lt-az-AZ	Azeri (Latin) - Azerbaijan	0x042C	 
eu-ES	Basque - Basque	0x042D	EUQ
be-BY	Belarusian - Belarus	0x0423	BEL
bg-BG	Bulgarian - Bulgaria	0x0402	BGR
ca-ES	Catalan - Catalan	0x0403	CAT
zh-CN	Chinese - China	0x0804	CHS
zh-HK	Chinese - Hong Kong SAR	0x0C04	ZHH
zh-MO	Chinese - Macau SAR	0x1404	 
zh-SG	Chinese - Singapore	0x1004	ZHI
zh-TW	Chinese - Taiwan	0x0404	CHT
zh-CHS	Chinese (Simplified)	0x0004	 
zh-CHT	Chinese (Traditional)	0x7C04	 
hr-HR	Croatian - Croatia	0x041A	HRV
cs-CZ	Czech - Czech Republic	0x0405	CSY
da-DK	Danish - Denmark	0x0406	DAN
div-MV	Dhivehi - Maldives	0x0465	 
nl-BE	Dutch - Belgium	0x0813	NLB
nl-NL	Dutch - The Netherlands	0x0413	 
en-AU	English - Australia	0x0C09	ENA
en-BZ	English - Belize	0x2809	ENL
en-CA	English - Canada	0x1009	ENC
en-CB	English - Caribbean	0x2409	 
en-IE	English - Ireland	0x1809	ENI
en-JM	English - Jamaica	0x2009	ENJ
en-NZ	English - New Zealand	0x1409	ENZ
en-PH	English - Philippines	0x3409	 
en-ZA	English - South Africa	0x1C09	ENS
en-TT	English - Trinidad and Tobago	0x2C09	ENT
en-GB	English - United Kingdom	0x0809	ENG
en-US	English - United States	0x0409	ENU
en-ZW	English - Zimbabwe	0x3009	 
et-EE	Estonian - Estonia	0x0425	ETI
fo-FO	Faroese - Faroe Islands	0x0438	FOS
fa-IR	Farsi - Iran	0x0429	FAR
fi-FI	Finnish - Finland	0x040B	FIN
fr-BE	French - Belgium	0x080C	FRB
fr-CA	French - Canada	0x0C0C	FRC
fr-FR	French - France	0x040C	 
fr-LU	French - Luxembourg	0x140C	FRL
fr-MC	French - Monaco	0x180C	 
fr-CH	French - Switzerland	0x100C	FRS
gl-ES	Galician - Galician	0x0456	 
ka-GE	Georgian - Georgia	0x0437	 
de-AT	German - Austria	0x0C07	DEA
de-DE	German - Germany	0x0407	 
de-LI	German - Liechtenstein	0x1407	DEC
de-LU	German - Luxembourg	0x1007	DEL
de-CH	German - Switzerland	0x0807	DES
el-GR	Greek - Greece	0x0408	ELL
gu-IN	Gujarati - India	0x0447	 
he-IL	Hebrew - Israel	0x040D	HEB
hi-IN	Hindi - India	0x0439	HIN
hu-HU	Hungarian - Hungary	0x040E	HUN
is-IS	Icelandic - Iceland	0x040F	ISL
id-ID	Indonesian - Indonesia	0x0421	 
it-IT	Italian - Italy	0x0410	 
it-CH	Italian - Switzerland	0x0810	ITS
ja-JP	Japanese - Japan	0x0411	JPN
kn-IN	Kannada - India	0x044B	 
kk-KZ	Kazakh - Kazakhstan	0x043F	 
kok-IN	Konkani - India	0x0457	 
ko-KR	Korean - Korea	0x0412	KOR
ky-KZ	Kyrgyz - Kazakhstan	0x0440	 
lv-LV	Latvian - Latvia	0x0426	LVI
lt-LT	Lithuanian - Lithuania	0x0427	LTH
mk-MK	Macedonian (FYROM)	0x042F	MKD
ms-BN	Malay - Brunei	0x083E	 
ms-MY	Malay - Malaysia	0x043E	 
mr-IN	Marathi - India	0x044E	 
mn-MN	Mongolian - Mongolia	0x0450	 
nb-NO	Norwegian (Bokm�l) - Norway	0x0414	 
nn-NO	Norwegian (Nynorsk) - Norway	0x0814	 
pl-PL	Polish - Poland	0x0415	PLK
pt-BR	Portuguese - Brazil	0x0416	PTB
pt-PT	Portuguese - Portugal	0x0816	 
pa-IN	Punjabi - India	0x0446	 
ro-RO	Romanian - Romania	0x0418	ROM
ru-RU	Russian - Russia	0x0419	RUS
sa-IN	Sanskrit - India	0x044F	 
Cy-sr-SP	Serbian (Cyrillic) - Serbia	0x0C1A	 
Lt-sr-SP	Serbian (Latin) - Serbia	0x081A	 
sk-SK	Slovak - Slovakia	0x041B	SKY
sl-SI	Slovenian - Slovenia	0x0424	SLV
es-AR	Spanish - Argentina	0x2C0A	ESS
es-BO	Spanish - Bolivia	0x400A	ESB
es-CL	Spanish - Chile	0x340A	ESL
es-CO	Spanish - Colombia	0x240A	ESO
es-CR	Spanish - Costa Rica	0x140A	ESC
es-DO	Spanish - Dominican Republic	0x1C0A	ESD
es-EC	Spanish - Ecuador	0x300A	ESF
es-SV	Spanish - El Salvador	0x440A	ESE
es-GT	Spanish - Guatemala	0x100A	ESG
es-HN	Spanish - Honduras	0x480A	ESH
es-MX	Spanish - Mexico	0x080A	ESM
es-NI	Spanish - Nicaragua	0x4C0A	ESI
es-PA	Spanish - Panama	0x180A	ESA
es-PY	Spanish - Paraguay	0x3C0A	ESZ
es-PE	Spanish - Peru	0x280A	ESR
es-PR	Spanish - Puerto Rico	0x500A	ES
es-ES	Spanish - Spain	0x0C0A	 
es-UY	Spanish - Uruguay	0x380A	ESY
es-VE	Spanish - Venezuela	0x200A	ESV
sw-KE	Swahili - Kenya	0x0441	 
sv-FI	Swedish - Finland	0x081D	SVF
sv-SE	Swedish - Sweden	0x041D	 
syr-SY	Syriac - Syria	0x045A	 
ta-IN	Tamil - India	0x0449	 
tt-RU	Tatar - Russia	0x0444	 
te-IN	Telugu - India	0x044A	 
th-TH	Thai - Thailand	0x041E	THA
tr-TR	Turkish - Turkey	0x041F	TRK
uk-UA	Ukrainian - Ukraine	0x0422	UKR
ur-PK	Urdu - Pakistan	0x0420	URD
Cy-uz-UZ	Uzbek (Cyrillic) - Uzbekistan	0x0843	 
Lt-uz-UZ	Uzbek (Latin) - Uzbekistan	0x0443	 
vi-VN	Vietnamese - Vietnam	0x042A	VIT
 


Culture     English Name	    Ui Culture
af	Afrikaans	af-ZA
af-ZA	Afrikaans (South Africa)	af-ZA
am-ET	Amharic (Ethiopia)	am-ET
ar	Arabic	ar-SA
ar-AE	Arabic (U.A.E.)	ar-AE
ar-BH	Arabic (Bahrain)	ar-BH
ar-DZ	Arabic (Algeria)	ar-DZ
ar-EG	Arabic (Egypt)	ar-EG
ar-IQ	Arabic (Iraq)	ar-IQ
ar-JO	Arabic (Jordan)	ar-JO
ar-KW	Arabic (Kuwait)	ar-KW
ar-LB	Arabic (Lebanon)	ar-LB
ar-LY	Arabic (Libya)	ar-LY
ar-MA	Arabic (Morocco)	ar-MA
arn-CL	Mapudungun (Chile)	arn-CL
ar-OM	Arabic (Oman)	ar-OM
ar-QA	Arabic (Qatar)	ar-QA
ar-SA	Arabic (Saudi Arabia)	ar-SA
ar-SY	Arabic (Syria)	ar-SY
ar-TN	Arabic (Tunisia)	ar-TN
ar-YE	Arabic (Yemen)	ar-YE
as-IN	Assamese (India)	as-IN
az	Azeri	az-Latn-AZ
az-Cyrl-AZ	Azeri (Cyrillic, Azerbaijan)	az-Cyrl-AZ
az-Latn-AZ	Azeri (Latin, Azerbaijan)	az-Latn-AZ
ba-RU	Bashkir (Russia)	ba-RU
be	Belarusian	be-BY
be-BY	Belarusian (Belarus)	be-BY
bg	Bulgarian	bg-BG
bg-BG	Bulgarian (Bulgaria)	bg-BG
bn-BD	Bengali (Bangladesh)	bn-BD
bn-IN	Bengali (India)	bn-IN
bo-CN	Tibetan (People's Republic of China)	bo-CN
br-FR	Breton (France)	br-FR
bs-Cyrl-BA	Bosnian (Cyrillic) (Bosnia and Herzegovina)	bs-Cyrl-BA
bs-Latn-BA	Bosnian (Latin) (Bosnia and Herzegovina)	bs-Latn-BA
ca	Catalan	ca-ES
ca-ES	Catalan (Catalan)	ca-ES
co-FR	Corsican (France)	co-FR
cs	Czech	cs-CZ
cs-CZ	Czech (Czech Republic)	cs-CZ
cy-GB	Welsh (United Kingdom)	cy-GB
da	Danish	da-DK
da-DK	Danish (Denmark)	da-DK
de	German	de-DE
de-AT	German (Austria)	de-AT
de-CH	German (Switzerland)	de-CH
de-DE	German (Germany)	de-DE
de-LI	German (Liechtenstein)	de-LI
de-LU	German (Luxembourg)	de-LU
dsb-DE	Lower Sorbian (Germany)	dsb-DE
dv	Divehi	dv-MV
dv-MV	Divehi (Maldives)	dv-MV
el	Greek	el-GR
el-GR	Greek (Greece)	el-GR
en	English	en-US
en-029	English (Caribbean)	en-029
en-AU	English (Australia)	en-AU
en-BZ	English (Belize)	en-BZ
en-CA	English (Canada)	en-CA
en-GB	English (United Kingdom)	en-GB
en-IE	English (Ireland)	en-IE
en-IN	English (India)	en-IN
en-JM	English (Jamaica)	en-JM
en-MY	English (Malaysia)	en-MY
en-NZ	English (New Zealand)	en-NZ
en-PH	English (Republic of the Philippines)	en-PH
en-SG	English (Singapore)	en-SG
en-TT	English (Trinidad and Tobago)	en-TT
en-US	English (United States)	en-US
en-ZA	English (South Africa)	en-ZA
en-ZW	English (Zimbabwe)	en-ZW
es	Spanish	es-ES
es-AR	Spanish (Argentina)	es-AR
es-BO	Spanish (Bolivia)	es-BO
es-CL	Spanish (Chile)	es-CL
es-CO	Spanish (Colombia)	es-CO
es-CR	Spanish (Costa Rica)	es-CR
es-DO	Spanish (Dominican Republic)	es-DO
es-EC	Spanish (Ecuador)	es-EC
es-ES	Spanish (Spain)	es-ES
es-GT	Spanish (Guatemala)	es-GT
es-HN	Spanish (Honduras)	es-HN
es-MX	Spanish (Mexico)	es-MX
es-NI	Spanish (Nicaragua)	es-NI
es-PA	Spanish (Panama)	es-PA
es-PE	Spanish (Peru)	es-PE
es-PR	Spanish (Puerto Rico)	es-PR
es-PY	Spanish (Paraguay)	es-PY
es-SV	Spanish (El Salvador)	es-SV
es-US	Spanish (United States)	es-US
es-UY	Spanish (Uruguay)	es-UY
es-VE	Spanish (Venezuela)	es-VE
et	Estonian	et-EE
et-EE	Estonian (Estonia)	et-EE
eu	Basque	eu-ES
eu-ES	Basque (Basque)	eu-ES
fa	Persian	fa-IR
fa-IR	Persian (Iran)	fa-IR
fi	Finnish	fi-FI
fi-FI	Finnish (Finland)	fi-FI
fil-PH	Filipino (Philippines)	fil-PH
fo	Faroese	fo-FO
fo-FO	Faroese (Faroe Islands)	fo-FO
fr	French	fr-FR
fr-BE	French (Belgium)	fr-BE
fr-CA	French (Canada)	fr-CA
fr-CH	French (Switzerland)	fr-CH
fr-FR	French (France)	fr-FR
fr-LU	French (Luxembourg)	fr-LU
fr-MC	French (Principality of Monaco)	fr-MC
fy-NL	Frisian (Netherlands)	fy-NL
ga-IE	Irish (Ireland)	ga-IE
gd-GB	Scottish Gaelic (United Kingdom)	gd-GB
gl	Galician	gl-ES
gl-ES	Galician (Galician)	gl-ES
gsw-FR	Alsatian (France)	gsw-FR
gu	Gujarati	gu-IN
gu-IN	Gujarati (India)	gu-IN
ha-Latn-NG	Hausa (Latin) (Nigeria)	ha-Latn-NG
he	Hebrew	he-IL
he-IL	Hebrew (Israel)	he-IL
hi	Hindi	hi-IN
hi-IN	Hindi (India)	hi-IN
hr	Croatian	hr-HR
hr-BA	Croatian (Latin) (Bosnia and Herzegovina)	hr-BA
hr-HR	Croatian (Croatia)	hr-HR
hsb-DE	Upper Sorbian (Germany)	hsb-DE
hu	Hungarian	hu-HU
hu-HU	Hungarian (Hungary)	hu-HU
hy	Armenian	hy-AM
hy-AM	Armenian (Armenia)	hy-AM
id	Indonesian	id-ID
id-ID	Indonesian (Indonesia)	id-ID
ig-NG	Igbo (Nigeria)	ig-NG
ii-CN	Yi (People's Republic of China)	ii-CN
is	Icelandic	is-IS
is-IS	Icelandic (Iceland)	is-IS
it	Italian	it-IT
it-CH	Italian (Switzerland)	it-CH
it-IT	Italian (Italy)	it-IT
iu-Cans-CA	Inuktitut (Syllabics) (Canada)	iu-Cans-CA
iu-Latn-CA	Inuktitut (Latin) (Canada)	iu-Latn-CA
ja	Japanese	ja-JP
ja-JP	Japanese (Japan)	ja-JP
ka	Georgian	ka-GE
ka-GE	Georgian (Georgia)	ka-GE
kk	Kazakh	kk-KZ
kk-KZ	Kazakh (Kazakhstan)	kk-KZ
kl-GL	Greenlandic (Greenland)	kl-GL
km-KH	Khmer (Cambodia)	km-KH
kn	Kannada	kn-IN
kn-IN	Kannada (India)	kn-IN
ko	Korean	ko-KR
kok	Konkani	kok-IN
kok-IN	Konkani (India)	kok-IN
ko-KR	Korean (Korea)	ko-KR
ky	Kyrgyz	ky-KG
ky-KG	Kyrgyz (Kyrgyzstan)	ky-KG
lb-LU	Luxembourgish (Luxembourg)	lb-LU
lo-LA	Lao (Lao P.D.R.)	lo-LA
lt	Lithuanian	lt-LT
lt-LT	Lithuanian (Lithuania)	lt-LT
lv	Latvian	lv-LV
lv-LV	Latvian (Latvia)	lv-LV
mi-NZ	Maori (New Zealand)	mi-NZ
mk	Macedonian	mk-MK
mk-MK	Macedonian (Former Yugoslav Republic of Macedonia)	mk-MK
ml-IN	Malayalam (India)	ml-IN
mn	Mongolian	mn-MN
mn-MN	Mongolian (Cyrillic, Mongolia)	mn-MN
mn-Mong-CN	Mongolian (Traditional Mongolian) (People's Republic of China)	mn-Mong-CN
moh-CA	Mohawk (Canada)	moh-CA
mr	Marathi	mr-IN
mr-IN	Marathi (India)	mr-IN
ms	Malay	ms-MY
ms-BN	Malay (Brunei Darussalam)	ms-BN
ms-MY	Malay (Malaysia)	ms-MY
mt-MT	Maltese (Malta)	mt-MT
nb-NO	Norwegian, Bokm�l (Norway)	nb-NO
ne-NP	Nepali (Nepal)	ne-NP
nl	Dutch	nl-NL
nl-BE	Dutch (Belgium)	nl-BE
nl-NL	Dutch (Netherlands)	nl-NL
nn-NO	Norwegian, Nynorsk (Norway)	nn-NO
no	Norwegian	nb-NO
nso-ZA	Sesotho sa Leboa (South Africa)	nso-ZA
oc-FR	Occitan (France)	oc-FR
or-IN	Oriya (India)	or-IN
pa	Punjabi	pa-IN
pa-IN	Punjabi (India)	pa-IN
pl	Polish	pl-PL
pl-PL	Polish (Poland)	pl-PL
prs-AF	Dari (Afghanistan)	prs-AF
ps-AF	Pashto (Afghanistan)	ps-AF
pt	Portuguese	pt-BR
pt-BR	Portuguese (Brazil)	pt-BR
pt-PT	Portuguese (Portugal)	pt-PT
qut-GT	K'iche (Guatemala)	qut-GT
quz-BO	Quechua (Bolivia)	quz-BO
quz-EC	Quechua (Ecuador)	quz-EC
quz-PE	Quechua (Peru)	quz-PE
rm-CH	Romansh (Switzerland)	rm-CH
ro	Romanian	ro-RO
ro-RO	Romanian (Romania)	ro-RO
ru	Russian	ru-RU
ru-RU	Russian (Russia)	ru-RU
rw-RW	Kinyarwanda (Rwanda)	rw-RW
sa	Sanskrit	sa-IN
sah-RU	Yakut (Russia)	sah-RU
sa-IN	Sanskrit (India)	sa-IN
se-FI	Sami (Northern) (Finland)	se-FI
se-NO	Sami (Northern) (Norway)	se-NO
se-SE	Sami (Northern) (Sweden)	se-SE
si-LK	Sinhala (Sri Lanka)	si-LK
sk	Slovak	sk-SK
sk-SK	Slovak (Slovakia)	sk-SK
sl	Slovenian	sl-SI
sl-SI	Slovenian (Slovenia)	sl-SI
sma-NO	Sami (Southern) (Norway)	sma-NO
sma-SE	Sami (Southern) (Sweden)	sma-SE
smj-NO	Sami (Lule) (Norway)	smj-NO
smj-SE	Sami (Lule) (Sweden)	smj-SE
smn-FI	Sami (Inari) (Finland)	smn-FI
sms-FI	Sami (Skolt) (Finland)	sms-FI
sq	Albanian	sq-AL
sq-AL	Albanian (Albania)	sq-AL
sr	Serbian	sr-Latn-CS
sr-Cyrl-BA	Serbian (Cyrillic) (Bosnia and Herzegovina)	sr-Cyrl-BA
sr-Cyrl-CS	Serbian (Cyrillic, Serbia and Montenegro (Former))	sr-Cyrl-CS
sr-Cyrl-ME	Serbian (Cyrillic) (Montenegro)	sr-Cyrl-ME
sr-Cyrl-RS	Serbian (Cyrillic) (Serbia)	sr-Cyrl-RS
sr-Latn-BA	Serbian (Latin) (Bosnia and Herzegovina)	sr-Latn-BA
sr-Latn-CS	Serbian (Latin, Serbia and Montenegro (Former))	sr-Latn-CS
sr-Latn-ME	Serbian (Latin) (Montenegro)	sr-Latn-ME
sr-Latn-RS	Serbian (Latin) (Serbia)	sr-Latn-RS
sv	Swedish	sv-SE
sv-FI	Swedish (Finland)	sv-FI
sv-SE	Swedish (Sweden)	sv-SE
sw	Kiswahili	sw-KE
sw-KE	Kiswahili (Kenya)	sw-KE
syr	Syriac	syr-SY
syr-SY	Syriac (Syria)	syr-SY
ta	Tamil	ta-IN
ta-IN	Tamil (India)	ta-IN
te	Telugu	te-IN
te-IN	Telugu (India)	te-IN
tg-Cyrl-TJ	Tajik (Cyrillic) (Tajikistan)	tg-Cyrl-TJ
th	Thai	th-TH
th-TH	Thai (Thailand)	th-TH
tk-TM	Turkmen (Turkmenistan)	tk-TM
tn-ZA	Setswana (South Africa)	tn-ZA
tr	Turkish	tr-TR
tr-TR	Turkish (Turkey)	tr-TR
tt	Tatar	tt-RU
tt-RU	Tatar (Russia)	tt-RU
tzm-Latn-DZ	Tamazight (Latin) (Algeria)	tzm-Latn-DZ
ug-CN	Uyghur (People's Republic of China)	ug-CN
uk	Ukrainian	uk-UA
uk-UA	Ukrainian (Ukraine)	uk-UA
ur	Urdu	ur-PK
ur-PK	Urdu (Islamic Republic of Pakistan)	ur-PK
uz	Uzbek	uz-Latn-UZ
uz-Cyrl-UZ	Uzbek (Cyrillic, Uzbekistan)	uz-Cyrl-UZ
uz-Latn-UZ	Uzbek (Latin, Uzbekistan)	uz-Latn-UZ
vi	Vietnamese	vi-VN
vi-VN	Vietnamese (Vietnam)	vi-VN
wo-SN	Wolof (Senegal)	wo-SN
xh-ZA	isiXhosa (South Africa)	xh-ZA
yo-NG	Yoruba (Nigeria)	yo-NG
zh-CHS	Chinese (Simplified)	(none)
zh-CHT	Chinese (Traditional)	(none)
zh-CN	Chinese (People's Republic of China)	zh-CN
zh-HK	Chinese (Hong Kong S.A.R.)	zh-HK
zh-MO	Chinese (Macao S.A.R.)	zh-MO
zh-SG	Chinese (Singapore)	zh-SG
zh-TW	Chinese (Taiwan)	zh-TW
zu-ZA	isiZulu (South Africa)	zu-ZA 
*/