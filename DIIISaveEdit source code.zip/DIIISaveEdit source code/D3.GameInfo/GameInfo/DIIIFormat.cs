#region Copyright

//  Copyright � 2013 - 2017 AWP ENT LLC (xx_CKY_xx at hotmail dot com)
//  
//   This(software is provided) 'as-is', without any express or implied
//   warranty. Under no circumstances will the authors be held liable for any damages encountered 
//   from the use of this software.
//  
//   Permission is granted to anyone to use this software for any purpose
//   excluding commercial applications, or to alter it and redistribute it
//   freely, subject to the following restrictions:
//  
//   1. The origin of this software must not be misrepresented; you must not
//     claim that you wrote the original software. If you use this software
//     in a product, an acknowledgment in the product documentation is required.
//  
//   2. Altered source versions must be plainly marked as such, and must not
//      be misrepresented as being the original software.
//  
//   3. This notice may not be removed or altered from any source distribution in any way.

#endregion

namespace D3.GameInfo
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.IO;
    using System.IO.Compression;
    using System.Linq;
    using System.Reflection;
    using System.Text;
    using System.Text.RegularExpressions;

    public class DIIIFormat
    {
        private static readonly Regex Codesignature =
            new Regex(@"DIII\((?<data>(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?)\)",
                RegexOptions.CultureInvariant | RegexOptions.Multiline);

        public static string CompressDiiiformat(object item)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("DIII(");
            //sb.Append(ClassToString(item));
            sb.Append(Convert.ToBase64String(Zip(ClassToString(item)), Base64FormattingOptions.None));
            sb.Append(")");
            return sb.ToString();
        }

        public static string[] DecompressDiiiFormat(string item)
        {
            item = Regex.Replace(item, @"\s+", string.Empty);
            foreach (var match in Codesignature.Matches(item).Cast<Match>()
                .Where(m => m.Success))
            {
                var code = match.Groups["data"].Value;
                byte[] data = Convert.FromBase64String(code);
                return Unzip(data).Split(new[] {"\r\n"}, StringSplitOptions.RemoveEmptyEntries);
            }

            return item.Split(new[] {"\r\n"}, StringSplitOptions.RemoveEmptyEntries);
        }

        public static void SetProperty(string compoundProperty, object target, string value)
        {
            Reflector.SetValue(target, compoundProperty, value);
        }

        public static void SetPropertyindex(string compoundProperty, object[] target, string value, int index)
        {
            string[] bits = compoundProperty.Split('.');
            for (int i = 0; i < bits.Length - 1; i++)
            {
                if (bits[i].IndexOf('[') > 0)
                {
                    bits[i] = bits[i].Substring(0, bits[i].IndexOf('['));
                }

                PropertyInfo propertyToGet = target.GetType().GetProperty(bits[i]);
                target[index] = propertyToGet.GetValue(target, null);
            }

            if (bits[bits.Length - 1].IndexOf('[') > 0)
            {
                bits[bits.Length - 1] = bits[bits.Length - 1].Substring(0, bits[bits.Length - 1].IndexOf('['));
                value = value.Trim('{', '}');

                PropertyInfo lstpropertyToSet = target.GetType().GetProperty(bits.Last());
                if (value != "null")
                {
                    List<int> list = new List<int>();
                    foreach (string s in value.Split(','))
                    {
                        list.Add(int.Parse(s));
                    }

                    lstpropertyToSet.SetValue(target, Convert.ChangeType(list, lstpropertyToSet.PropertyType), null);
                }

                return;
            }

            PropertyInfo propertyToSet = target.GetType().GetProperty(bits.Last());
            if (value != "null")
            {
                propertyToSet.SetValue(target, Convert.ChangeType(value, propertyToSet.PropertyType), null);
            }
        }

        public static string ClassToString(object o, string name = "", int depth = 15)
        {
            try
            {
                var leafprefix = string.IsNullOrWhiteSpace(name) ? name : name + " = ";
                if (null == o)
                {
                    return leafprefix + "null";
                }

                var t = o.GetType();
                if (depth-- < 1 || t == typeof (string) || t.IsValueType)
                {
                    return leafprefix + o;
                }

                var sb = new StringBuilder();
                var enumerable = o as IEnumerable;
                if (enumerable != null)
                {
                    name = (name ?? string.Empty).TrimEnd('[', ']') + '[';
                    var elements = enumerable.Cast<object>().Select(e => ClassToString(e, string.Empty, depth)).ToList();
                    var arrayInOneLine = elements.Count + "] = {" + string.Join(",", elements) + '}';
                    if (!arrayInOneLine.Contains(Environment.NewLine))
                    {
                        return name + arrayInOneLine;
                    }

                    var i = 0;
                    foreach (var element in elements)
                    {
                        var lineheader = name + i++ + ']';
                        sb.Append(lineheader)
                            .AppendLine(element.Replace(Environment.NewLine, Environment.NewLine + lineheader));
                    }

                    return sb.ToString();
                }

                foreach (var f in t.GetFields())
                {
                    sb.AppendLine(ClassToString(f.GetValue(o), name + '.' + f.Name, depth));
                }

                foreach (var p in t.GetProperties())
                {
                    sb.AppendLine(ClassToString(p.GetValue(o, null), name + '.' + p.Name, depth));
                }

                if (sb.Length == 0)
                {
                    return leafprefix + o;
                }

                return sb.ToString().TrimEnd();
            }
            catch (Exception ex)
            {
                Log.LogMessage(ex.TargetSite.Name, Log.GetLineNumber(ex), ex.StackTrace, ELogflag.Critical);
                return name + "???";
            }
        }

        private static void CopyTo(Stream src, Stream dest)
        {
            byte[] bytes = new byte[4096];

            int cnt;
            while ((cnt = src.Read(bytes, 0, bytes.Length)) != 0)
            {
                dest.Write(bytes, 0, cnt);
            }
        }

        private static string Unzip(byte[] bytes)
        {
            using (MemoryStream  msi = new MemoryStream(bytes))
            using (MemoryStream mso = new MemoryStream())
            {
                using (var gs = new GZipStream(msi, CompressionMode.Decompress))
                {
                    CopyTo(gs, mso);
                }
                return Encoding.UTF8.GetString(mso.ToArray());
            }
        }

        private static byte[] Zip(string str)
        {
            var bytes = Encoding.UTF8.GetBytes(str);
            using (MemoryStream msi = new MemoryStream(bytes))
            using (MemoryStream mso = new MemoryStream())
            {
                using (var gs = new GZipStream(mso, CompressionMode.Compress))
                {
                    CopyTo(msi, gs);
                }
                return mso.ToArray();
            }
        }
    }
}