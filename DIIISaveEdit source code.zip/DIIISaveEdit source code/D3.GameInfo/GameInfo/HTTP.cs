#region Copyright

//  Copyright � 2013 - 2017 AWP ENT LLC (xx_CKY_xx at hotmail dot com)
//  
//   This(software is provided) 'as-is', without any express or implied
//   warranty. Under no circumstances will the authors be held liable for any damages encountered 
//   from the use of this software.
//  
//   Permission is granted to anyone to use this software for any purpose
//   excluding commercial applications, or to alter it and redistribute it
//   freely, subject to the following restrictions:
//  
//   1. The origin of this software must not be misrepresented; you must not
//     claim that you wrote the original software. If you use this software
//     in a product, an acknowledgment in the product documentation is required.
//  
//   2. Altered source versions must be plainly marked as such, and must not
//      be misrepresented as being the original software.
//  
//   3. This notice may not be removed or altered from any source distribution in any way.

#endregion

namespace D3.GameInfo
{

    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.IO;
    using System.Net;
    using System.Reflection;
    using System.Collections;

    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    public static class HTTP
    {
        public static CookieContainer cookieJar = new CookieContainer();
        public static Dictionary<string, string> cookieDict = new Dictionary<string, string>();

        public static string HttpPostRequest(string url, Dictionary<string, string> postParameters, string encoding, System.Diagnostics.FileVersionInfo fv)
        {
            try
            {
                string postData = "";
                foreach (string key in postParameters.Keys)
                {
                    postData += Uri.EscapeDataString(key) + "=" + StringExtension.ReplaceBase64toUri(postParameters[key]) + "&";
                }
                postData = postData.TrimEnd('&');
                HttpWebRequest myHttpWebRequest = (HttpWebRequest)HttpWebRequest.Create(url);
                System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Ssl3;
                myHttpWebRequest.Method = "POST";
                byte[] data = Encoding.ASCII.GetBytes(postData);
                myHttpWebRequest.Timeout = 20000;
                myHttpWebRequest.ContentType = "application/x-www-form-urlencoded";
                myHttpWebRequest.ContentLength = data.Length;
                myHttpWebRequest.UserAgent = "DIIIRoS/" + fv.FileVersion;
                myHttpWebRequest.KeepAlive = false;
                myHttpWebRequest.CookieContainer = cookieJar;
                Stream requestStream = myHttpWebRequest.GetRequestStream();
                requestStream.Write(data, 0, data.Length);
                requestStream.Close();
                HttpWebResponse myHttpWebResponse = (HttpWebResponse)myHttpWebRequest.GetResponse();
                cookieJar.Add(myHttpWebResponse.Cookies);
                foreach (Cookie c in myHttpWebResponse.Cookies)
                {
                    if (!cookieDict.ContainsKey(c.Name.ToString()))
                    {
                        cookieDict.Add(c.Name, c.Value);
                    }
                    else
                    {
                        cookieDict[c.Name] = c.Value;
                    }
                }
                Stream responseStream = myHttpWebResponse.GetResponseStream();
                Encoding tc = Encoding.GetEncoding(encoding);
                StreamReader myStreamReader = new StreamReader(responseStream, tc);
                string pageContent = myStreamReader.ReadToEnd();
                myStreamReader.Close();
                responseStream.Close();
                myHttpWebResponse.Close();
                return pageContent;
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message);
                return null;
            }
        }
    }
}