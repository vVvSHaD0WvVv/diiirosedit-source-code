#region Copyright

//  Copyright � 2013 - 2017 AWP ENT LLC (xx_CKY_xx at hotmail dot com)
//  
//   This(software is provided) 'as-is', without any express or implied
//   warranty. Under no circumstances will the authors be held liable for any damages encountered 
//   from the use of this software.
//  
//   Permission is granted to anyone to use this software for any purpose
//   excluding commercial applications, or to alter it and redistribute it
//   freely, subject to the following restrictions:
//  
//   1. The origin of this software must not be misrepresented; you must not
//     claim that you wrote the original software. If you use this software
//     in a product, an acknowledgment in the product documentation is required.
//  
//   2. Altered source versions must be plainly marked as such, and must not
//      be misrepresented as being the original software.
//  
//   3. This notice may not be removed or altered from any source distribution in any way.

#endregion

namespace D3.GameInfo
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Diagnostics.CodeAnalysis;
    using System.Globalization;
    using System.Reflection;

    public struct ConversionResult
    {
        public object ConvertedValue;
        public Boolean Success;
    }

    public static class Reflector
    {
        // ReSharper disable ConvertToConstant.Local
        // ReSharper disable FieldCanBeMadeReadOnly.Local
        private static BindingFlags _defaultbindings = BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance |
                                                       BindingFlags.NonPublic;

        // ReSharper restore FieldCanBeMadeReadOnly.Local
        // ReSharper restore ConvertToConstant.Local

        public static Boolean CanCreateObect(string classPath, Assembly assembly, params object[] parameters)
        {
            Boolean canCreate = false;
            Type type = Type.GetType(classPath);
            if (type == null)
            {
                string pathWithAssembly = classPath + ", " + assembly.FullName;
                type = Type.GetType(pathWithAssembly);
            }

            if (type != null)
            {
                foreach (ConstructorInfo ci in type.GetConstructors())
                {
                    if (ci.IsPublic)
                    {
                        ParameterInfo[] constructorParameters = ci.GetParameters();
                        if (constructorParameters.Length == parameters.Length)
                        {
                            for (Int32 i = 0; i < constructorParameters.Length; i++)
                            {
                                object parameter = parameters[i];
                                if (parameter == null)
                                {
                                    continue;
                                }

                                ParameterInfo pi = constructorParameters[i];
                                // ReSharper disable UseMethodIsInstanceOfType
                                if (!pi.ParameterType.IsAssignableFrom(parameter.GetType()))
                                    // ReSharper restore UseMethodIsInstanceOfType
                                {
                                    break;
                                }
                            }
                            canCreate = true;
                            break;
                        }
                    }
                }
            }
            return canCreate;
        }

        /// <summary>
        ///     Convert the object to the correct type
        /// </summary>
        /// <param name="value">Value to convert</param>
        /// <param name="type">Type to convert to</param>
        /// <param name="typeConverter">Type</param>
        /// <returns>Converted value</returns>
        public static ConversionResult ConvertValue(object value, Type type, TypeConverter typeConverter)
        {
            ConversionResult conversionResult = new ConversionResult();
            conversionResult.Success = false;
            Type objectType = value.GetType();
            if((string)value != "null" && (string)value != ""  && (string)value != "{}" && (string)value != string.Empty)
            {
                if (type != null)
                {
                   objectType = value.GetType();
                    if (objectType == type)
                    {
                        conversionResult.Success = true;
                        conversionResult.ConvertedValue = value;
                    }
                    else
                    {
                        if (typeConverter != null && typeConverter.CanConvertFrom(objectType))
                        {
                            try
                            {
                                conversionResult.ConvertedValue = typeConverter.ConvertFrom(value);
                                conversionResult.Success = true;
                            }
                            catch (FormatException)
                            {
                            }
                            catch (Exception ex)
                            {
                                Log.LogMessage(ex.TargetSite.Name, Log.GetLineNumber(ex), ex.StackTrace, ELogflag.Critical);
                                if (!(ex.InnerException is FormatException))
                                {
                                    throw;
                                }
                            }
                        }
                        else
                        {
                            try
                            {
                                conversionResult.ConvertedValue = Convert.ChangeType(value, type, CultureInfo.CurrentCulture);
                                conversionResult.Success = true;
                            }
                            catch (InvalidCastException)
                            {
                            }
                        }
                    }
                }
            }
            return conversionResult;
        }

        /// <summary>
        ///     Copies all public properties and fields from source to target
        /// </summary>
        /// <param name="source"></param>
        /// <param name="target"></param>
        public static void CopyObject(object source, object target)
        {
            if (source != null && target != null)
            {
                Type targetType = target.GetType();
                Type sourceType = source.GetType();

                PropertyInfo[] properties = sourceType.GetProperties(_defaultbindings);
                foreach (PropertyInfo sourceProperty in properties)
                {
                    PropertyInfo targetProperty = targetType.GetProperty(sourceProperty.Name,
                        sourceProperty.PropertyType);
                    if (targetProperty != null && targetProperty.CanRead && targetProperty.CanWrite)
                    {
                        object value = sourceProperty.GetValue(source, null);
                        targetProperty.SetValue(target, value, null);
                    }
                }

                FieldInfo[] fields = sourceType.GetFields(_defaultbindings);
                foreach (FieldInfo sourceField in fields)
                {
                    FieldInfo targetField = targetType.GetField(sourceField.Name);
                    if (targetField != null && targetField.IsPublic)
                    {
                        object value = sourceField.GetValue(source);
                        targetField.SetValue(target, value);
                    }
                }
            }
        }

        public static object CreateObject(string classPath, Assembly assembly, params object[] parameters)
        {
            Type type = Type.GetType(classPath);
            if (type == null)
            {
                string pathWithAssembly = classPath + ", " + assembly.FullName;
                type = Type.GetType(pathWithAssembly);
            }

            if (type == null)
            {
                return null;
            }
            return Activator.CreateInstance(type, parameters);
        }

        /// <summary>
        ///     Executes the method on the "source" object with the passed parameters
        /// </summary>
        /// <param name="source">Object the code should be executed against</param>
        /// <param name="methodName">Method to call</param>
        /// <param name="parameters">Method Parameters</param>
        /// <returns>object </returns>
        public static object ExecuteMethod(object source, string methodName, object[] parameters)
        {
            if (parameters == null)
            {
                parameters = new object[0];
            }

            MethodInfo[] methodInfos = GetMethods(source, methodName);

            foreach (MethodInfo methodInfo in methodInfos)
            {
                object[] convertedParameters = GetParameters(methodInfo, parameters);
                if (convertedParameters != null)
                {
                    return methodInfo.Invoke(source, convertedParameters);
                }
            }
            return null;
        }

        /// <summary>
        ///     Executes the method on the "source" object with the passed parameters
        /// </summary>
        /// <param name="source">Object the code should be executed against</param>
        /// <param name="methodName">Method to call</param>
        /// <param name="parameter">Method Parameter</param>
        public static object ExecuteMethod(object source, string methodName, object parameter)
        {
            return ExecuteMethod(source, methodName, new[] {parameter});
        }

        /// <summary>
        ///     Executes the method on the "source" object with no parameters
        /// </summary>
        /// <param name="source">Object the code should be executed against</param>
        /// <param name="methodName">Method to call</param>
        public static object ExecuteMethod(object source, string methodName)
        {
            return ExecuteMethod(source, methodName, null);
        }

        /// <summary>
        ///     Execute the "codeToExecute" string on the "source" object
        /// </summary>
        /// <param name="source">Object the code should be executed against</param>
        /// <param name="codeToExecute">Code that should be executed ex. 'Person.Age'</param>
        /// <returns>The result of execute codeToExecute on source</returns>
        public static object GetValue(object source, string codeToExecute)
        {
            ReflectorResult reflectorResult = GetReflectorResult(source, codeToExecute, true, false);
            if (reflectorResult != null)
            {
                return reflectorResult.Value;
            }
            return null;
        }

        /// <summary>
        ///     Sets the "source" object to the "value" specified in "codeToExecute"
        /// </summary>
        /// <param name="source">Object the code should be executed against</param>
        /// <param name="codeToExecute">Code that should be executed ex. 'Person.Age'</param>
        public static void RunDynamicCode(object source, string codeToExecute)
        {
            GetReflectorResult(source, codeToExecute, true, false);
        }

        /// <summary>
        ///     Sets the "source" object to the "value" specified in "codeToExecute"
        /// </summary>
        /// <param name="source">Object the code should be executed against</param>
        /// <param name="codeToExecute">Code that should be executed ex. 'Person.Age'</param>
        /// <param name="value">Value to set the source+codeToExecute to.</param>
        /// <returns>Boolean</returns>
        public static Boolean SetValue(object source, string codeToExecute, object value)
        {
            return SetValue(source, codeToExecute, value, false);
        }

        /// <summary>
        ///     Sets the "source" object to the "value" specified in "codeToExecute"
        /// </summary>
        /// <param name="source">Object the code should be executed against</param>
        /// <param name="codeToExecute">Code that should be executed ex. 'Person.Age'</param>
        /// <param name="value">Value to set the source+codeToExecute to.</param>
        /// <param name="createIfNotExists">Creates items it cannot find</param>
        /// <returns>Boolean</returns>
        public static Boolean SetValue(object source, string codeToExecute, object value, Boolean createIfNotExists)
        {
            Boolean executed = true;

            ReflectorResult reflectorResult = GetReflectorResult(source, codeToExecute, false, createIfNotExists);
            if (reflectorResult != null)
            {
                TypeConverter typeConverter;
                PropertyInfo propertyInfo = reflectorResult.MemberInfo as PropertyInfo;
                if (propertyInfo != null)
                {
                    if (propertyInfo.CanWrite)
                    {
                        typeConverter = GetTypeConverter(propertyInfo);

                        ConversionResult conversionResult = ConvertValue(value, propertyInfo.PropertyType, typeConverter);
                        if (conversionResult.Success)
                        {
                            propertyInfo.SetValue(reflectorResult.PreviousValue, conversionResult.ConvertedValue,
                                reflectorResult.MemberInfoParameters);
                        }
                        else
                        {
                            PropertyInfo lstpropertyToSet = (PropertyInfo) reflectorResult.MemberInfo;
                            if (lstpropertyToSet.PropertyType.Name == "List`1")
                            {
                                if ((string)value != "null" && (string)value != "" && (string)value != string.Empty)
                                {
                                    value = value.ToString().Trim('{', '}');
                                    List<int> list = new List<int>();
                                    foreach (string s in value.ToString().Split(','))
                                    {
                                        if ((string)value != "null" && (string)value != "" &&
                                            (string)value != string.Empty)
                                        {
                                            list.Add(Int32.Parse(s));
                                        }
                                    }
                                    lstpropertyToSet.SetValue(reflectorResult.PreviousValue,
                                        Convert.ChangeType(list, lstpropertyToSet.PropertyType),
                                        reflectorResult.MemberInfoParameters);
                                }
                            }
                            else
                            {
                                executed = false;
                                //Log.LogMessage("SetValue", 0, "Invalid value: " + value, ELogflag.Log);
                            }
                        }
                    }
                }
                else
                {
                    FieldInfo fieldInfo = reflectorResult.MemberInfo as FieldInfo;
                    if (fieldInfo != null)
                    {
                        typeConverter = GetTypeConverter(fieldInfo);
                        ConversionResult conversionResult = ConvertValue(value, fieldInfo.FieldType, typeConverter);
                        if (conversionResult.Success)
                        {
                            fieldInfo.SetValue(reflectorResult.PreviousValue, conversionResult.ConvertedValue);
                        }
                        else
                        {
                            executed = false;
                        }
                    }
                    else
                    {
                        executed = false;
                    }
                }
            }
            else
            {
                executed = false;
            }

            return executed;
        }

        private static Boolean CreateArrayItem(ReflectorResult result, ArrayDefinition arrayDefinition)
        {
            Type resultType = result.Value.GetType();
            Type containedType = resultType.IsArray ? resultType.GetElementType() : resultType.GetGenericArguments()[0];

            object newInstance = Activator.CreateInstance(containedType);
            if (!resultType.IsArray)
            {
                MethodInfo[] methods = GetMethods(result.Value, "Insert");
                foreach (MethodInfo methodInfo in methods)
                {
                    object[] temp = new object[arrayDefinition.Parameters.Length + 1];
                    arrayDefinition.Parameters.CopyTo(temp, 0);
                    temp[arrayDefinition.Parameters.Length] = newInstance;

                    object[] parameters = GetParameters(methodInfo, temp);
                    if (parameters != null)
                    {
                        methodInfo.Invoke(result.Value, parameters);
                        return true;
                    }
                }
            }
            return false;
        }

        private static ArrayDefinition GetArrayDefinition(object value, string codeToExecute)
        {
            List<MemberInfo> retrieveMemberInfos = new List<MemberInfo>();
            foreach (PropertyInfo propertyInfo in value.GetType().GetProperties(_defaultbindings))
            {
                if (propertyInfo.Name == "Item")
                {
                    retrieveMemberInfos.Add(propertyInfo);
                }
            }

            if (retrieveMemberInfos.Count == 0)
            {
                foreach (MethodInfo methodInfo in value.GetType().GetMethods(_defaultbindings))
                {
                    if (methodInfo.Name == "GetValue")
                    {
                        retrieveMemberInfos.Add(methodInfo);
                    }
                }
            }

            foreach (MemberInfo memberInfo in retrieveMemberInfos)
            {
                object[] parameters = GetParameters(codeToExecute, memberInfo);
                if (parameters != null)
                {
                    ArrayDefinition arrayDefinition = new ArrayDefinition();
                    arrayDefinition.Parameters = parameters;
                    arrayDefinition.RetrieveMemberInfo = memberInfo;
                    return arrayDefinition;
                }
            }
            return null;
        }

        private static MethodInfo[] GetMethods(object value, string methodName)
        {
            if (string.IsNullOrEmpty(methodName))
            {
                throw new ArgumentNullException("methodName");
            }

            if (value == null)
            {
                return new MethodInfo[0];
            }

            List<MethodInfo> methodInfos = new List<MethodInfo>();
            foreach (MethodInfo methodInfo in value.GetType().GetMethods(_defaultbindings))
            {
                if (methodInfo.Name == methodName)
                {
                    methodInfos.Add(methodInfo);
                }
            }
            return methodInfos.ToArray();
        }

        private static object[] GetParameters(string codeFragment, MemberInfo memberInfo)
        {
            string parameters = SplitParametersFromMethod(codeFragment);
            if (string.IsNullOrEmpty(parameters))
            {
                return new object[0];
            }

            // ReSharper disable CoVariantArrayConversion
            object[] parameterArray = parameters.Split(',');
            // ReSharper restore CoVariantArrayConversion
            return GetParameters(memberInfo, parameterArray);
        }

        private static object[] GetParameters(MemberInfo memberInfo, object[] parameterArray)
        {
            ParameterInfo[] parameterInfo = null;
            TypeConverter typeConverter = null;

            PropertyInfo propertyInfo = memberInfo as PropertyInfo;
            if (propertyInfo != null)
            {
                parameterInfo = propertyInfo.GetIndexParameters();
                typeConverter = GetTypeConverter(parameterInfo[0]);
            }
            else
            {
                MethodInfo methodInfo = memberInfo as MethodInfo;
                if (methodInfo != null)
                {
                    parameterInfo = methodInfo.GetParameters();
                }
            }

            if (parameterInfo == null)
            {
                return null;
            }

            object[] returnParameters = new object[parameterInfo.Length];
            for (Int32 i = 0; i < parameterArray.Length; i++)
            {
                ConversionResult converstionResult = ConvertValue(parameterArray[i], parameterInfo[i].ParameterType,
                    typeConverter);
                if (converstionResult.Success)
                {
                    returnParameters[i] = converstionResult.ConvertedValue;
                }
                else
                {
                    return null;
                }
            }
            return returnParameters;
        }

        private static ReflectorResult GetReflectorResult(object source, string codeToExecute, bool getLastValue,
            bool createIfNotExists)
        {
            ReflectorResult result = new ReflectorResult(source);

            try
            {
                string[] codeFragments = SplitCodeArray(codeToExecute);
                for (Int32 i = 0; i < codeFragments.Length; i++)
                {
                    if (result.Value == null)
                    {
                        return result;
                    }

                    string codeFragment = codeFragments[i];
                    result.PreviousValue = result.Value;

                    if (codeFragment.Contains("]"))
                    {
                        ProcessArray(result, codeFragment, createIfNotExists);
                    }
                    else if (codeFragment.Contains(")"))
                    {
                        ProcessMethod(result, codeFragment);
                    }
                    else
                    {
                        bool retrieveValue = getLastValue;
                        if (!retrieveValue)
                        {
                            retrieveValue = i + 1 != codeFragments.Length;
                        }
                        ProcessProperty(result, codeFragment, retrieveValue);
                    }
                }
            }
            catch (InvalidCodeFragmentException ex)
            {
                //Log.LogMessage(ex.TargetSite.Name, Log.GetLineNumber(ex),
                //    "Invalid Property: '" + codeToExecute + "' Invalid Fragment: '" + ex.StackTrace, ELogflag.Log);
                Console.Write("Invalid Property: '" + codeToExecute + "' Invalid Fragment: '" + ex.StackTrace + "'");
                           
            }
            return result;
        }

        private static TypeConverter GetTypeConverter(MemberInfo memberInfo, Type targetType)
        {
            object[] typeConverters = memberInfo.GetCustomAttributes(typeof (TypeConverterAttribute), true);
            if (typeConverters.Length > 0)
            {
                TypeConverterAttribute typeConverterAttribute = (TypeConverterAttribute) typeConverters[0];
                Type typeFromName = Type.GetType(typeConverterAttribute.ConverterTypeName);
                if ((typeFromName != null) && typeof (TypeConverter).IsAssignableFrom(typeFromName))
                {
                    return (TypeConverter) Activator.CreateInstance(typeFromName);
                }
            }
            return TypeDescriptor.GetConverter(targetType);
        }

        private static TypeConverter GetTypeConverter(PropertyInfo propertyInfo)
        {
            return GetTypeConverter(propertyInfo, propertyInfo.PropertyType);
        }

        private static TypeConverter GetTypeConverter(FieldInfo fieldInfo)
        {
            return GetTypeConverter(fieldInfo, fieldInfo.FieldType);
        }

        private static TypeConverter GetTypeConverter(ParameterInfo parameterInfo)
        {
            return GetTypeConverter(parameterInfo.Member, parameterInfo.ParameterType);
        }

        private static void ProcessArray(ReflectorResult result, string codeFragment, Boolean createIfNotExists)
        {
            Int32 failCount = 0;
            ArrayDefinition arrayDefinition = GetArrayDefinition(result.Value, codeFragment);
            if (arrayDefinition != null)
            {
                PropertyInfo propertyInfo = arrayDefinition.RetrieveMemberInfo as PropertyInfo;
                if (propertyInfo != null)
                {
                    SetPropertyInfoValue:
                    try
                    {
                        object value = propertyInfo.GetValue(result.Value, arrayDefinition.Parameters);
                        result.SetResult(value, propertyInfo, arrayDefinition.Parameters);
                    }
                    catch (TargetInvocationException ex)
                    {
                        failCount++;
                        if (ex.InnerException is ArgumentOutOfRangeException && failCount == 1 && createIfNotExists)
                        {
                            if (CreateArrayItem(result, arrayDefinition))
                            {
                                goto SetPropertyInfoValue;
                            }
                        }

                        result.Clear();
                        throw new InvalidCodeFragmentException(codeFragment);
                    }
                }
                else
                {
                    MethodInfo methodInfo = arrayDefinition.RetrieveMemberInfo as MethodInfo;
                    if (methodInfo != null)
                    {
                        try
                        {
                            object value = methodInfo.Invoke(result.Value, arrayDefinition.Parameters);
                            result.SetResult(value, methodInfo, arrayDefinition.Parameters);
                        }
                        catch (TargetInvocationException)
                        {
                            result.Clear();
                            throw new InvalidCodeFragmentException(codeFragment);
                        }
                    }
                }
            }
            else
            {
                result.Clear();
                throw new InvalidCodeFragmentException(codeFragment);
            }
        }

        private static void ProcessMethod(ReflectorResult result, string codeFragment)
        {
            string methodName = codeFragment.Substring(0, codeFragment.IndexOf('('));
            MethodInfo[] methodInfos = GetMethods(result.Value, methodName);

            foreach (MethodInfo methodInfo in methodInfos)
            {
                object[] parameters = GetParameters(codeFragment, methodInfo);
                if (parameters != null)
                {
                    object value = methodInfo.Invoke(result.Value, parameters);
                    result.SetResult(value, null, null);
                    break;
                }
            }
        }

        private static void ProcessProperty(ReflectorResult result, string codeFragment, bool retrieveValue)
        {
            PropertyInfo propertyInfo = result.Value.GetType().GetProperty(codeFragment, _defaultbindings);
            if (propertyInfo != null)
            {
                object value = result.Value;
                if (retrieveValue)
                {
                    value = propertyInfo.GetValue(result.Value, null);
                    result.SetResult(value, propertyInfo, null);
                }
                result.SetResult(value, propertyInfo, null);
            }
            else
            {
                FieldInfo fieldInfo = result.Value.GetType().GetField(codeFragment, _defaultbindings);
                if (fieldInfo != null)
                {
                    object value = result.Value;
                    if (retrieveValue)
                    {
                        value = fieldInfo.GetValue(result.Value);
                    }
                    result.SetResult(value, fieldInfo, null);
                }
                else
                {
                    result.Clear();
                    throw new InvalidCodeFragmentException(codeFragment);
                }
            }
        }

        private static string[] SplitCodeArray(string codeToExecute)
        {
            List<string> items = new List<string>();

            Int32 parenAndbracketCount = 0;
            string buffer = "";
            // ReSharper disable RedundantStringToCharArrayCall
            foreach (Char c in codeToExecute.ToCharArray())
                // ReSharper restore RedundantStringToCharArrayCall
            {
                // ReSharper disable once ConvertIfStatementToSwitchStatement
                if (c == '.')
                {
                    if (buffer.Length > 0)
                    {
                        items.Add(buffer);
                        buffer = "";
                    }
                    continue;
                }
                else if (c == '[')
                {
                    parenAndbracketCount++;
                    if (buffer.Length > 0)
                    {
                        items.Add(buffer);
                    }
                    buffer = c.ToString();
                }
                else if (c == ']' || c == ')')
                {
                    parenAndbracketCount--;
                    buffer += c;
                    if (buffer.Length > 0)
                    {
                        items.Add(buffer);
                        buffer = "";
                    }
                }
                else if (c == '(')
                {
                    parenAndbracketCount++;
                    buffer += c;
                }
                else if (Char.IsWhiteSpace(c) || Char.IsControl(c))
                {
                    if (parenAndbracketCount == 0)
                    {
                        continue;
                    }
                    else
                    {
                        buffer += c;
                    }
                }
                else
                {
                    buffer += c;
                }
            }
            if (buffer.Length > 0)
            {
                items.Add(buffer);
            }
            return items.ToArray();
        }

        private static string SplitParametersFromMethod(string codeFragment)
        {
            char startCharacter = '[';
            char endCharacter = ']';

            if (codeFragment.EndsWith(")", StringComparison.CurrentCulture))
            {
                startCharacter = '(';
                endCharacter = ')';
            }

            Int32 startParam = codeFragment.IndexOf(startCharacter) + 1;
            if (startParam < 1)
            {
                return null;
            }

            Int32 endParam = codeFragment.IndexOf(endCharacter);
            if (endParam < 0)
            {
                return null;
            }

            return codeFragment.Substring(startParam, endParam - startParam).Trim();
        }

        private class ArrayDefinition
        {
            public object[] Parameters { get; set; }

            public MemberInfo RetrieveMemberInfo { get; set; }
        }

        [Serializable]
        [SuppressMessage("Microsoft.Design", "CA1064:ExceptionsShouldBePublic")]
        [SuppressMessage("Microsoft.Design", "CA1032:ImplementStandardExceptionConstructors")]
        private class InvalidCodeFragmentException : Exception
        {
            public InvalidCodeFragmentException(string invalidFragment)
                : base(invalidFragment)
            {
            }
        }

        private class ReflectorResult
        {
            public ReflectorResult(object startValue)
            {
                SetResult(startValue, null, null);
            }

            public MemberInfo MemberInfo { get; private set; }

            public object[] MemberInfoParameters { get; private set; }

            public object PreviousValue { get; set; }

            public object Value { get; private set; }

            public void Clear()
            {
                MemberInfo = null;
                Value = null;
                PreviousValue = null;
            }

            public void SetResult(object value, MemberInfo memberInfo, object[] memberInfoParameters)
            {
                Value = value;
                MemberInfo = memberInfo;
                MemberInfoParameters = memberInfoParameters;
            }
        }
    }
}