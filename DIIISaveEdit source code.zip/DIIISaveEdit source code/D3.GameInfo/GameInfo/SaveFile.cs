#region Copyright

//  Copyright � 2013 - 2017 AWP ENT LLC (xx_CKY_xx at hotmail dot com)
//  
//   This(software is provided) 'as-is', without any express or implied
//   warranty. Under no circumstances will the authors be held liable for any damages encountered 
//   from the use of this software.
//  
//   Permission is granted to anyone to use this software for any purpose
//   excluding commercial applications, or to alter it and redistribute it
//   freely, subject to the following restrictions:
//  
//   1. The origin of this software must not be misrepresented; you must not
//     claim that you wrote the original software. If you use this software
//     in a product, an acknowledgment in the product documentation is required.
//  
//   2. Altered source versions must be plainly marked as such, and must not
//      be misrepresented as being the original software.
//  
//   3. This notice may not be removed or altered from any source distribution in any way.

#endregion


namespace D3.GameInfo
{
    using System.IO;

    public class SaveFile
    {
        public static Stream Savedecryptfile(string file)
        {
            byte[] bytes = File.ReadAllBytes(file);
            var seed = 0x305F92D82EC9A01BUL;
            for (int i = 0; i < bytes.Length; i++)
            {
                bytes[i] ^= (byte)(seed & 0xFF);
                seed = ((seed ^ bytes[i]) << 56) | (seed >> 8);
            }
            return new MemoryStream(bytes);
        }

        public static FileStream Saveencryptfile(string file)
        {
            byte[] bytes = File.ReadAllBytes(file);
            var seed = 0x305F92D82EC9A01BUL;
            for (int i = 0; i < bytes.Length; i++)
            {
                var value = bytes[i];
                bytes[i] ^= (byte)(seed & 0xFF);
                seed = ((seed ^ value) << 56) | (seed >> 8);
            }
            Stream stream = new MemoryStream(bytes);
            return (FileStream)stream;
        }

        public static Stream Savedecryptstreeam(Stream instream)
        {
            using (var memoryStream = new MemoryStream())
            {
                instream.CopyTo(memoryStream);
                byte[] bytes = memoryStream.ToArray();
                var seed = 0x305F92D82EC9A01BUL;
                for (int i = 0; i < bytes.Length; i++)
                {
                    bytes[i] ^= (byte)(seed & 0xFF);
                    seed = ((seed ^ bytes[i]) << 56) | (seed >> 8);
                }
                Stream stream = new MemoryStream(bytes);
                return stream;
            }
        }

        public static Stream Saveencryptstream(Stream instream)
        {
            using (var memoryStream = new MemoryStream())
            {
                instream.Position = 0;
                instream.CopyTo(memoryStream);
                byte[] bytes = memoryStream.ToArray();
                var seed = 0x305F92D82EC9A01BUL;
                for (int i = 0; i < bytes.Length; i++)
                {
                    var value = bytes[i];
                    bytes[i] ^= (byte)(seed & 0xFF);
                    seed = ((seed ^ value) << 56) | (seed >> 8);
                }
                Stream stream = new MemoryStream(bytes);
                return stream;
            }
        }
    }
}