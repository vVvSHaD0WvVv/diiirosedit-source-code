#region Copyright

//  Copyright � 2013 - 2017 AWP ENT LLC (xx_CKY_xx at hotmail dot com)
//  
//   This(software is provided) 'as-is', without any express or implied
//   warranty. Under no circumstances will the authors be held liable for any damages encountered 
//   from the use of this software.
//  
//   Permission is granted to anyone to use this software for any purpose
//   excluding commercial applications, or to alter it and redistribute it
//   freely, subject to the following restrictions:
//  
//   1. The origin of this software must not be misrepresented; you must not
//     claim that you wrote the original software. If you use this software
//     in a product, an acknowledgment in the product documentation is required.
//  
//   2. Altered source versions must be plainly marked as such, and must not
//      be misrepresented as being the original software.
//  
//   3. This notice may not be removed or altered from any source distribution in any way.

#endregion

namespace D3.GameInfo
{
    using System;
    using System.IO;
    using System.Text;

    public static class Log
    {
        public static string ApplicationPath { get; set; }
        private const string DatePatt = @"M/d/yyyy hh:mm:ss tt";

        public static void LogMessage(string method, int line, string msg, ELogflag flag, string title = "")
        {
            DateTime now = DateTime.Now;
            StringBuilder sb = new StringBuilder();

            sb.Append("------ LOG DATA " + now.ToString(DatePatt) + " ------\r\n");
            switch (flag)
            {
                case ELogflag.Log:
                    sb.Append("[LOG]");
                    break;
                case ELogflag.Critical:
                    sb.Append("[CRITICAL]");
                    break;
                case ELogflag.Custom:
                    title = title.ToUpper();
                    sb.Append("[" + title + "]");
                    break;
                default:
                    sb.Append("[UNKNOWN]");
                    break;
            }
            sb.Append("\r\n");
            sb.Append("Method=" + method + "\r\n");
            sb.Append("Line=" + line + "\r\n");
            sb.Append("Message=" + msg + "\r\n");
            //Console.WriteLine(sb.ToString());
            if (Directory.Exists(ApplicationPath + "\\Error\\") == false)
            {
                Directory.CreateDirectory(ApplicationPath + "\\Error\\");
            }
            string filepath = ApplicationPath + "\\Error\\" + now.ToString("M-d-yy") + ".LOG";
            // ReSharper disable once LoopVariableIsNeverChangedInsideLoop
            while(IsFileLocked(new FileInfo(filepath)))
            {
                File.AppendAllText(filepath, sb.ToString());
            }
        }

        public static int GetLineNumber(Exception ex)
        {
            var lineNumber = 0;
            const string lineSearch = ":line ";
            var index = ex.StackTrace.LastIndexOf(lineSearch, StringComparison.Ordinal);
            if (index != -1)
            {
                var lineNumberText = ex.StackTrace.Substring(index + lineSearch.Length);
                if (int.TryParse(lineNumberText, out lineNumber))
                {
                }
            }
            return lineNumber;
        }

        private static bool IsFileLocked(FileInfo file)
        {
            FileStream stream = null;

            try
            {
                stream = file.Open(FileMode.Open, FileAccess.ReadWrite, FileShare.None);
            }
            catch (IOException)
            {
                //the file is unavailable because it is:
                //still being written to
                //or being processed by another thread
                //or does not exist (has already been processed)
                return true;
            }
            finally
            {
                if (stream != null)
                    stream.Close();
            }

            //file is not locked
            return false;
        }
    }

    public enum ELogflag
    {
        Log,
        Critical,
        Custom,
        Unknown
    }
}