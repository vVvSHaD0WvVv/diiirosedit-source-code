﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.ComponentModel;
//using System.Windows.Media;
using System.Globalization;
using System.Resources;

namespace D3.Ui
{
    [ToolboxBitmap(typeof(ToolTip))]
    public class AdvancedToolTip : ToolTip, IComponent
    {
        //private static RichTextBox _selCtrl = new RichTextBox();
        private readonly ResourceManager _rm = new ResourceManager(typeof(D3Strings));
        private Size _definedSize = new Size(100, 70);
        private static Bitmap _backGround = Properties.Resources.BreathMeter_Fill_Empty;
        private static System.Drawing.Color _titleColor = System.Drawing.Color.White;
        private static System.Drawing.Color _descriptionColor = System.Drawing.Color.White;
        private const float _fontSize = 10F;
        private static Font _descriptionFont = new Font("Times new roman", _fontSize, FontStyle.Regular);
        private static Font _titleFont = new Font("Times new roman", _fontSize, FontStyle.Bold);
        private IList<string> __d;
        private Size tSize = new Size(0, 0);
        private static string _desctiptionText = string.Empty;
        private string _titleText = "";
        private List<ToolTipControl> ToolTipControls = new List<ToolTipControl>();


        /// <summary>
        /// Provides information about ToolTips that are associated with their controls.
        /// This structure is used specifically with the 'GetToolTip(control)' method.
        /// </summary>
        public struct ToolTipControl
        {
            public Control Control; public string Title; public string Description;
        }

        /// <summary>
        /// Associates ToolTip title and description with the specified control.
        /// </summary>
        /// <param name="control">The System.Windows.Forms.Control to associate the ToolTip text with.</param>
        /// <param name="description">The ToolTip description to display when the the ToolTip is shown over the specified control.</param>
        /// <param name="title">The ToolTip title to display when the ToolTip is shown.</param>
        public void SetToolTip(Control control, string description, string title)
        {
            if (title == null) title = string.Empty;
            bool _found = false;
            for (int i = 0; i < ToolTipControls.Count; i++)
            {
                var ctrl = ToolTipControls[i];
                if (ctrl.Control == control)
                {
                    _found = true;
                    ctrl.Title = title;
                    ctrl.Description = description;
                }
            }

            if (!_found)
            {
                ToolTipControls.Add(new ToolTipControl()
                {
                    Control = control,
                    Title = title,
                    Description = description
                });
            }
            base.SetToolTip(control, description);
        }

        // For customizing a ToolTip there are two main values that must be set as follows:
        // 'OwnerDraw = true' & 'IsBalloon = false'
        // So our ToolTip is going to be customized, then let's hide those two properties
        // from 'Editor' & 'IntelliSense' for avoiding any possible styling errors!
        [Browsable(false)]
        [EditorBrowsable(EditorBrowsableState.Never)]
        new public bool OwnerDraw { get; set; }

        [Browsable(false)]
        [EditorBrowsable(EditorBrowsableState.Never)]
        new public bool IsBalloon { get; set; }

        [Browsable(false)]
        [EditorBrowsable(EditorBrowsableState.Never)]
        new public System.Drawing.Color ForeColor { get; set; }

        /// <summary>
        /// Gets or sets the background color for the ToolTip.
        /// No background color is taken into account when a background image is set!
        /// </summary>
        [Description("Gets or sets the background color for the ToolTip.\n\nNote: No background color will be taken into account if a background image is set!")]
        new public System.Drawing.Color BackColor { get { return base.BackColor; } set { base.BackColor = value; } }

        /// <summary>
        /// Associates ToolTip title and description with the specified control.
        /// </summary>
        /// <param name="control">The System.Windows.Forms.Control to associate the ToolTip text with.</param>
        /// <param name="description">The ToolTip description to display when the the ToolTip is shown over the specified control.</param>
        new public void SetToolTip(Control control, string description)
        {
            #region
            bool _found = false;
            for (int i = 0; i < ToolTipControls.Count; i++)
            {
                var ctrl = ToolTipControls[i];
                if (ctrl.Control == control)
                {
                    _found = true;
                    ctrl.Description = description;

                }
            }

            if (!_found)
            {
                ToolTipControls.Add(new ToolTipControl()
                {
                    Control = control,
                    Title = string.Empty,
                    Description = description
                });
            }
            #endregion
            base.SetToolTip(control, description);
        }

        /// <summary>
        /// Removes the associated ToolTip from the specified control.
        /// </summary>
        /// <param name="control">The System.Windows.Forms.Control to associate the ToolTip text with.</param>
        public void RemoveToolTip(Control control)
        {
            foreach (var x in ToolTipControls)
            {
                if (x.Control.Equals(control))
                {
                    ToolTipControls.Remove(x);
                }
            }
        }

        /// <summary>
        /// Gets the associated ToolTip with the specified control.
        /// </summary>
        new public ToolTipControl GetToolTip(Control control)
        {
            ToolTipControl n = new ToolTipControl();
            foreach (var x in ToolTipControls) { if (x.Control == control) { n = x; } }
            return n;
        }

        /// <summary>
        /// Specifies a title for the ToolTip to use when it is about to be displayed
        /// but only when no title was set for a control in the ToolTip!
        /// </summary>
        [DefaultValue("ToolTip title")]
        new public string ToolTipTitle
        {
            get
            {
                return _titleText;
            }
            set
            {
                _titleText = value;
            }
        }

        #region Done!

        /// <summary>
        /// In order to set this you must set the AutoSize value to false.
        /// </summary>
        [Browsable(false)]
        [EditorBrowsable(EditorBrowsableState.Never)]
        public Size Size
        {
            get { return _definedSize; }
            set { _definedSize = value; }
        }

        private Bitmap ResizeBitmap(Bitmap srcImage, int newWidth, int newHeight)
        {
            Bitmap newImage = new Bitmap(newWidth, newHeight);
            using (Graphics gr = Graphics.FromImage(newImage))
            {
                // Drawing our custom background
                gr.SmoothingMode = SmoothingMode.HighQuality;
                gr.InterpolationMode = InterpolationMode.HighQualityBicubic;
                gr.PixelOffsetMode = PixelOffsetMode.HighQuality;
                gr.SmoothingMode = SmoothingMode.HighQuality;
                gr.DrawImage(srcImage, new Rectangle(0, 0, newWidth, newHeight));
            }

            return newImage;
        }

        /// <summary>
        /// Gets or sets the ToolTip description content.
        /// </summary>
        private string ToolTipDescription
        {
            get { return _desctiptionText; }
            set
            {
                string _tmp = value;
                while (_tmp.Contains("  ")) { _tmp = _tmp.Replace("  ", " "); };
                while (_tmp.Contains("\n\n")) { _tmp = _tmp.Replace("\n\n", "\n"); };
                //MessageBox.Show(_tmp);
                _desctiptionText = _tmp;
            }
        }

        /// <summary>
        /// Gets or sets the title brush.
        /// </summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public System.Drawing.Color TitleColor
        {
            get { return _titleColor; }
            set
            {
                if (value == null)
                {
                    _titleColor = System.Drawing.Color.White;
                }
                else
                {
                    _titleColor = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the description brush.
        /// </summary>
        public System.Drawing.Color DescriptionColor
        {
            get { return _descriptionColor; }
            set
            {
                if (value == null)
                {
                    _descriptionColor = System.Drawing.Color.White;
                }
                else
                {
                    _descriptionColor = value;
                }
            }
        }

        /// <summary>
        /// Gets or sets the ToolTip background image.
        /// </summary>
        public Bitmap BackgroundImage
        {
            get { return _backGround; }
            set
            {
                _backGround = value;
            }
        }

        /// <summary>
        /// Specifies a Font value for the title on the ToolTip.
        /// </summary>
        public Font TitleFont
        {
            get { return _titleFont; }
            set
            {
                _titleFont = value;
            }
        }

        /// <summary>
        /// Specifies a Font value for the description on the ToolTip.
        /// </summary>
        public Font DescriptionFont
        {
            get { return _descriptionFont; }
            set
            {
                _descriptionFont = value;
            }
        }

        [Browsable(false)]
        [EditorBrowsable(EditorBrowsableState.Never)]
        new public bool StripAmpersands { get; set; }

        public AdvancedToolTip()
        {
            base.OwnerDraw = true;
            this.Popup += new PopupEventHandler(this.OnPopup);
            this.Draw += new DrawToolTipEventHandler(this.OnDraw);
            this.InitialDelay = 1;
            this.ReshowDelay = 500;
            // Force the ToolTip text to be displayed whether or not the control active.
            this.ShowAlways = true;
        }

        private void OnPopup(object sender, PopupEventArgs e)
        {
            var r = new Bitmap(e.ToolTipSize.Width, e.ToolTipSize.Height);
            var g = Graphics.FromImage(r);
            foreach (var __tCtrl in ToolTipControls)
            {
                Control ctrl = __tCtrl.Control;
                if (ctrl == e.AssociatedControl)
                {
                    // Set the appropriate title
                    if (__tCtrl.Title.Trim() == string.Empty)
                    {
                        _titleText = this.ToolTipTitle;
                    }
                    else
                    {
                        _titleText = __tCtrl.Title;
                    }
                    // Set the description
                    //__d = GetWordwrapped(__tCtrl.Description,this.DescriptionFont, e.AssociatedWindow.Handle);
                    __d = __tCtrl.Description.Split(new string[] { Environment.NewLine }, StringSplitOptions.None);
                }
            }

            SizeF szD = new SizeF(0, 0);
            List<Size> DescriptionSize = new List<Size>();

            foreach (string stringlist in __d)
            {

                var size = TextRenderer.MeasureText(stringlist, DescriptionFont, new Size(260, 0), TextFormatFlags.WordBreak);
                //var a = g.MeasureString(stringlist, this.DescriptionFont);
                if (size.Width > szD.Width)
                {
                    if (size.Width < 260)
                    {
                        szD = size;
                    }
                    else
                    {
                        szD.Width = 260;
                        szD.Height = size.Height;
                    }
                }
                DescriptionSize.Add(new Size(size.Width, size.Height));
            }
            int height = 0;
            foreach (Size size in DescriptionSize)
            {
                height += size.Height;
            }
            int checkmath = height / DescriptionSize.Count;
            var szT = g.MeasureString(_titleText, this.TitleFont);

            // Set ToolTip's size according to the Title text property
            if (__d.Count == 0)
            {
                // Set ToolTip size without respecting the description's size
                e.ToolTipSize = new Size((int)szT.Width + 10, (int)(szT.Height) + 10);
            }
            else
            {
                // Set ToolTip size by taking into account the description's size
                var wF = szT.Width;
                if (wF < szD.Width)
                {
                    wF = szD.Width;
                }
                var hF = 21 + height;// +DescriptionSize.Count;
                e.ToolTipSize = new Size((int)wF + 60, (int)hF);
            }
        }
                
        private void OnDraw(object sender, DrawToolTipEventArgs e) // use this event to customize the tool tip
        {

            //Get current control needed data
            // Set our background
            
            Graphics g = e.Graphics;
            Image _rightImage = new Bitmap(Properties.Resources.RightTab);
            Image _leftImage = new Bitmap(Properties.Resources.LeftTab);
            Image _borderImage = new Bitmap(Properties.Resources.BorderTab);
            if (BackgroundImage != null)
            {
                var n = BackgroundImage.Clone() as Bitmap;
                var rectSz = e.Bounds.Size;
                n = ResizeBitmap(n, rectSz.Width, rectSz.Height);
                g.Clear(BackColor);
                g.DrawImage(n, 0, 0);
            }
            e.DrawBorder();
            System.Drawing.Color _Color = new System.Drawing.Color();
            //_eColor = System.Drawing.Color.White;
            _Color = TitleColor;
            if (_titleText.ToLower().Contains(_rm.GetString("_Set").TrimStart(' ').ToLower()))
            {
                _Color = System.Drawing.Color.Lime;
            }
            else if (_titleText.ToLower().Contains(_rm.GetString("_Legendary").TrimStart(' ').ToLower()))
            {
                _Color = System.Drawing.Color.Orange;
            }

            // Draw our ToolTip title
            RectangleF TitleRectF = new RectangleF(new PointF(0, 0), new Size(e.Bounds.Width, _borderImage.Height));
            StringFormat stringFormat = new StringFormat();
            stringFormat.Alignment = StringAlignment.Center;
            stringFormat.LineAlignment = StringAlignment.Center;
            System.Drawing.Graphics graphicsObject = e.Graphics;

            using (System.Drawing.Brush aGradientBrush = new System.Drawing.Drawing2D.LinearGradientBrush(TitleRectF, System.Drawing.Color.Black, _Color, LinearGradientMode.Vertical))
            {
                System.Drawing.Brush aGradientBrush2 = new System.Drawing.Drawing2D.LinearGradientBrush(TitleRectF, _Color, System.Drawing.Color.Black, LinearGradientMode.Vertical);
                graphicsObject.FillRectangle(aGradientBrush, TitleRectF.X, TitleRectF.Y, TitleRectF.Width, TitleRectF.Height / 2);//, new Point(0, 4), new Point(e.Bounds.Width, 10));
                graphicsObject.FillRectangle(aGradientBrush2, TitleRectF.X, TitleRectF.Height / 2, TitleRectF.Width, TitleRectF.Height / 2);//, new Point(0, 4), new Point(e.Bounds.Width, 10));
            }

            e.Graphics.DrawImage(_rightImage, new Rectangle((int)TitleRectF.Width - _rightImage.Width, 0, _rightImage.Width, _rightImage.Height));
            e.Graphics.DrawImage(_leftImage, new Rectangle(0, 0, _leftImage.Width, _leftImage.Height));
            e.Graphics.DrawImage(_borderImage, TitleRectF);
            g.DrawString((_titleText).Trim('\n'), TitleFont, new SolidBrush(_Color), TitleRectF, stringFormat);//new PointF(18, 4),
            // Draw each line of the description and bullets
            int height = _borderImage.Height;
            foreach (string stringlistitem in __d)
            {
                string stringitem = stringlistitem;
                var szD = g.MeasureString(stringitem, DescriptionFont);
                var size = TextRenderer.MeasureText(stringitem, DescriptionFont, new Size(e.Bounds.Width - ((int)szD.Height + 5), 0), TextFormatFlags.WordBreak);
                int offset = 5;
                if (stringitem.Contains("\t"))
                {
                    stringitem = stringitem.Replace("\t", "");
                    Image _bullet = new Bitmap(Properties.Resources.DiamondBullet);
                    Rectangle rect2 = new Rectangle(5, height, (int)szD.Height, (int)szD.Height);
                    e.Graphics.DrawImage(_bullet, rect2);
                    e.Graphics.DrawRectangle(Pens.Transparent, Rectangle.Round(rect2));
                    offset = (int)szD.Height + 5;
                }

                Rectangle rect1 = new Rectangle(offset, height, e.Bounds.Width - (offset + 5), size.Height);
                e.Graphics.DrawString(stringitem, DescriptionFont, new SolidBrush(DescriptionColor), rect1);
                e.Graphics.DrawRectangle(Pens.Transparent, Rectangle.Round(rect1));
                height += size.Height;
            }
        }
    }
        #endregion
}