#region Copyright

//  Copyright � 2013 - 2017 AWP ENT LLC (xx_CKY_xx at hotmail dot com)
//  
//   This(software is provided) 'as-is', without any express or implied
//   warranty. Under no circumstances will the authors be held liable for any damages encountered 
//   from the use of this software.
//  
//   Permission is granted to anyone to use this software for any purpose
//   excluding commercial applications, or to alter it and redistribute it
//   freely, subject to the following restrictions:
//  
//   1. The origin of this software must not be misrepresented; you must not
//     claim that you wrote the original software. If you use this software
//     in a product, an acknowledgment in the product documentation is required.
//  
//   2. Altered source versions must be plainly marked as such, and must not
//      be misrepresented as being the original software.
//  
//   3. This notice may not be removed or altered from any source distribution in any way.

#endregion

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Resources;
using System.Windows.Forms;
using D3.Ui.Properties;
using System.Runtime.InteropServices;
//using System.Windows.Media;

namespace D3.Ui
{
    public partial class InfoTip : UserControl
    {
        private const float FontSize = 10F;
        private static Color _titleColor = Color.White;
        private static Color _descriptionColor = Color.Black;
        private static Font _descriptionFont = new Font("Microsoft Sans Serif", FontSize, FontStyle.Regular);
        private static Font _titleFont = new Font("Microsoft Sans Serif", FontSize, FontStyle.Bold);
        private static string _desctiptionText = string.Empty;
        private readonly ResourceManager _rm = new ResourceManager(typeof(D3Strings));
        private IList<string> __d;
        private string _titleText = "";
        [DllImport("user32.dll")]
        private static extern bool LockWindowUpdate(IntPtr hWnd);
        //private int height = 0;
        [Browsable(false)]
        [EditorBrowsable(EditorBrowsableState.Never)]
        public new Color ForeColor { get; set; }

        /// <summary>
        ///     Gets or sets the background color for the InfoPane.
        ///     No background color is taken into account when a background image is set!
        /// </summary>
        [Description(
            "Gets or sets the background color for the InfoPane.\r\nNote: No background color will be taken into account if a background image is set!"
            )]
        public new Color BackColor
        {
            get { return base.BackColor; }
            set { base.BackColor = value; }
        }

        /// <summary>
        ///     Specifies a title for the InfoPane to use when it is about to be displayed
        ///     but only when no title was set for a control in the InfoPane!
        /// </summary>
        [DefaultValue("InfoPane title")]
        public string InfoPaneTitle
        {
            get { return _titleText; }
            set
            {
                if (_titleText != value)
                {
                    _titleText = value;
                    Refresh();
                }
            }
        }

        public InfoTip()
        {
            DoubleBuffered = true;
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.ResizeRedraw, true);
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            UpdateStyles();
            AutoScrollMinSize = new Size(this.Width, this.Height);
            InitializeComponent();
        }

        private Bitmap ResizeBitmap(Bitmap srcImage, int newWidth, int newHeight)
        {
            var newImage = new Bitmap(newWidth, newHeight);
            using (var gr = Graphics.FromImage(newImage))
            {
                // Drawing our custom background
                gr.SmoothingMode = SmoothingMode.HighQuality;
                gr.InterpolationMode = InterpolationMode.HighQualityBicubic;
                gr.PixelOffsetMode = PixelOffsetMode.HighQuality;
                gr.SmoothingMode = SmoothingMode.HighQuality;
                gr.DrawImage(srcImage, new Rectangle(0, 0, newWidth, newHeight));
            }

            return newImage;
        }

        /// <summary>
        ///     Gets or sets the InfoPane description content.
        /// </summary>
        public string InfoPaneDescription
        {
            get { return _desctiptionText; }
            set
            {
                string _tmp = value;
                while (_tmp.Contains("  ")) { _tmp = _tmp.Replace("  ", " "); };
                while (_tmp.Contains("\n\n")) { _tmp = _tmp.Replace("\n\n", "\n"); };
                if (_tmp != _desctiptionText)
                {
                    //MessageBox.Show(_tmp);
                    _desctiptionText = _tmp; 
                    var stringFormat = new StringFormat(StringFormat.GenericTypographic);
                    __d =_desctiptionText.Split(new[] { Environment.NewLine }, StringSplitOptions.None);
                    var r = new Bitmap(this.Width, this.Height);
                    var g = Graphics.FromImage(r);
                    var height = 21;
                    stringFormat = new StringFormat(StringFormat.GenericTypographic);
                    stringFormat.Alignment = StringAlignment.Near;
                    stringFormat.FormatFlags = StringFormatFlags.MeasureTrailingSpaces;
                    foreach (var stringlistitem in __d)
                    {
                        var stringitem = stringlistitem;
                        var szD = g.MeasureString(tabstring(stringitem), DescriptionFont);
                        var size = g.MeasureString(tabstring(stringitem), DescriptionFont, new Size(this.Width, 0), stringFormat);
                        var offset = 5;
                        if (stringitem.Contains("\t"))
                        {
                            size = g.MeasureString(tabstring(stringitem), DescriptionFont, new Size(this.Width - ((int)szD.Height ), 0), stringFormat);
                            //g.DrawRectangle(Pens.Transparent, Rectangle.Ceiling(rect2));
                            offset = (int)szD.Height + 5;
                        }
                        var rect1 = new RectangleF(offset, height, this.Width - (offset + 5), (int)size.Height + (DescriptionFont.Size * DescriptionFont.FontFamily.GetCellDescent(DescriptionFont.Style) / DescriptionFont.FontFamily.GetEmHeight(DescriptionFont.Style)));
                       //g.DrawRectangle(Pens.Transparent, Rectangle.Ceiling(rect1));
                        height += (int)(Rectangle.Ceiling(rect1).Height);
                    }
                    this.Height = height;
                    Refresh();
                    Invalidate();
                }
            }

        }

        /// <summary>
        ///     Gets or sets the title brush.
        /// </summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public Color TitleColor
        {
            get { return _titleColor; }
            set
            {
                if (value == null)
                {
                    _titleColor = Color.White;
                }
                else
                {
                    _titleColor = value;
                }
            }
        }

        /// <summary>
        ///     Gets or sets the description brush.
        /// </summary>
        public Color DescriptionColor
        {
            get { return _descriptionColor; }
            set
            {
                if (value == null)
                {
                    _descriptionColor = Color.White;
                }
                else
                {
                    _descriptionColor = value;
                }
            }
        }

        /// <summary>
        ///     Specifies a Font value for the title on the InfoPane.
        /// </summary>
        public Font TitleFont
        {
            get { return _titleFont; }
            set { _titleFont = value; }
        }

        /// <summary>
        ///     Specifies a Font value for the description on the InfoPane.
        /// </summary>
        public Font DescriptionFont
        {
            get { return _descriptionFont; }
            set { _descriptionFont = value; }
        }

        [Browsable(false)]
        [EditorBrowsable(EditorBrowsableState.Never)]
        public bool StripAmpersands { get; set; }
        protected override void OnScroll(ScrollEventArgs se)
        {
            if (se.Type == ScrollEventType.First) LockWindowUpdate(this.Handle);
            else if (se.Type == ScrollEventType.ThumbTrack || se.Type == ScrollEventType.ThumbPosition)
            {
                LockWindowUpdate(IntPtr.Zero);
                this.Refresh();
                LockWindowUpdate(this.Handle);
            }
            else
            {
                LockWindowUpdate(IntPtr.Zero);
                this.Invalidate();
            }
            base.OnScroll(se);
        }
        protected override void OnPaint(PaintEventArgs e) // use this event to customize the tool tip
        {
            using (SolidBrush br = new SolidBrush(this.BackColor))
                e.Graphics.FillRectangle(br, this.ClientRectangle);
            if (BackgroundImage != null) e.Graphics.DrawImage(BackgroundImage, this.ClientRectangle);
            base.OnPaint(e);
            var g = e.Graphics;
            Image _rightImage = new Bitmap(Resources.RightTab);
            Image _leftImage = new Bitmap(Resources.LeftTab);
            Image _borderImage = new Bitmap(Resources.BorderTab);
            __d = InfoPaneDescription.Split(new[] { Environment.NewLine }, StringSplitOptions.None);
            if (_titleText != "")
            {

                _titleText = _titleText.Replace("h 2", "h�2");
                var _titleSize = new Size();
                var szT = g.MeasureString(_titleText, TitleFont);
                if ((int)szT.Width + SystemInformation.VerticalScrollBarWidth < e.ClipRectangle.Width)
                {
                    _titleSize.Height = _leftImage.Height;
                    _titleSize.Width = _leftImage.Width;
                }
                else
                {
                    _titleSize.Height = _leftImage.Height * 2;
                    _titleSize.Width = _leftImage.Width + 10;
                }

                var scrollOffset = AutoScrollPosition;
               
                    var hassc = 0;
                    if (VerticalScroll.Visible)
                    {
                        hassc = SystemInformation.VerticalScrollBarWidth;
                    }
                    else
                    {
                        hassc = 0;
                    }
                    var _Color = new Color();
                    _Color = TitleColor;
                    if (_titleText.ToLower().Contains(_rm.GetString("_Set").TrimStart(' ').ToLower()))
                    {
                        _Color = Color.Lime;
                    }
                    else if (_titleText.ToLower().Contains(_rm.GetString("_Legendary").TrimStart(' ').ToLower()))
                    {
                        _Color = Color.Orange;
                    }

                    // Draw our InfoPane title
                    var stringFormat = new StringFormat(StringFormat.GenericTypographic);
                    stringFormat.Alignment = StringAlignment.Center;
                    stringFormat.LineAlignment = StringAlignment.Center;
                    var TitleRectF = new RectangleF(new PointF(0, 0), new Size(Width - hassc, _titleSize.Height));
                    using (Brush aGradientBrush = new LinearGradientBrush(TitleRectF, Color.Black, _Color, LinearGradientMode.Vertical))
                    {
                        Brush aGradientBrush2 = new LinearGradientBrush(TitleRectF, _Color, Color.Black, LinearGradientMode.Vertical);
                        g.FillRectangle(aGradientBrush, TitleRectF.X, TitleRectF.Y, TitleRectF.Width, TitleRectF.Height / 2);
                        g.FillRectangle(aGradientBrush2, TitleRectF.X, TitleRectF.Height / 2, TitleRectF.Width, TitleRectF.Height / 2);
                    }
                    g.DrawImage(_rightImage, new Rectangle((int)TitleRectF.Width - _titleSize.Width, 0, _titleSize.Width, _titleSize.Height));
                    g.DrawImage(_leftImage, new Rectangle(0, 0, _titleSize.Width, _titleSize.Height));
                    g.DrawImage(_borderImage, TitleRectF);
                    g.DrawString(_titleText.Trim('\n'), TitleFont, new SolidBrush(_Color), TitleRectF, stringFormat);
                    // Draw each line of the description and bullets
                    var height = _titleSize.Height;
                    stringFormat = new StringFormat(StringFormat.GenericTypographic);
                    stringFormat.Alignment = StringAlignment.Near;
                    stringFormat.FormatFlags = StringFormatFlags.MeasureTrailingSpaces;
                    foreach (var stringlistitem in __d)
                    {
                        var stringitem = stringlistitem;
                        var szD = g.MeasureString(tabstring(stringitem), DescriptionFont);
                        var size = g.MeasureString(tabstring(stringitem), DescriptionFont, new Size(e.ClipRectangle.Width - hassc, 0), stringFormat);
                        var offset = 5;
                        if (stringitem.Contains("\t"))
                        {
                            size = g.MeasureString(tabstring(stringitem), DescriptionFont, new Size(e.ClipRectangle.Width - ((int)szD.Height + hassc), 0), stringFormat);
                            Image _bullet = new Bitmap(Resources.DiamondBullet);
                            var rect2 = new RectangleF(5, height, (int)szD.Height, (int)szD.Height);
                            g.DrawImage(_bullet, rect2);
                            //g.DrawRectangle(Pens.Transparent, Rectangle.Ceiling(rect2));
                            offset = (int)szD.Height + 5;
                        }
                        var rect1 = new RectangleF(offset, height, e.ClipRectangle.Width - (offset + 5), (int)size.Height + (DescriptionFont.Size * DescriptionFont.FontFamily.GetCellDescent(DescriptionFont.Style) / DescriptionFont.FontFamily.GetEmHeight(DescriptionFont.Style)));
                        g.DrawString(tabstring(stringitem), DescriptionFont, new SolidBrush(DescriptionColor), rect1, stringFormat);
                        //g.DrawRectangle(Pens.Transparent, Rectangle.Ceiling(rect1));
                        height += (int)(Rectangle.Ceiling(rect1).Height);
                    }
            }
            else
            {
                var TitleRectF = new RectangleF(new PointF(0, 0), new Size(Width, 21));
                using (Brush aGradientBrush = new LinearGradientBrush(TitleRectF, Color.Black, Color.White, LinearGradientMode.Vertical))
                {
                    Brush aGradientBrush2 = new LinearGradientBrush(TitleRectF, Color.White, Color.Black, LinearGradientMode.Vertical);
                    g.FillRectangle(aGradientBrush, TitleRectF.X, TitleRectF.Y, TitleRectF.Width, TitleRectF.Height / 2);
                    g.FillRectangle(aGradientBrush2, TitleRectF.X, TitleRectF.Height / 2, TitleRectF.Width, TitleRectF.Height / 2);
                }
                g.DrawImage(_rightImage, new Rectangle((int)TitleRectF.Width - 15, 0, 15, 21));
                g.DrawImage(_leftImage, new Rectangle(0, 0, 15, 21));
                g.DrawImage(_borderImage, TitleRectF);
            }
        }

        private string tabstring(string stringtoreplace)
        {
            return stringtoreplace.Replace("\t", "");
        }
    }
}