﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using D3.GameInfo;
using D3.Ui.LoginDialog;
using System.Reflection;
using System.Security.Principal;
using System.Resources;
using System.Drawing;
using System.Text;

namespace D3.Ui
{
    public partial class ToS : Form
    {
        private ToolTipOverride _tip = new ToolTipOverride();
        private long _lasttime;
        private readonly ResourceManager _rm = new ResourceManager(typeof(D3Strings));
        private readonly Uri _uri = new Uri(loginHelper.weburl + "ToSA.php?mac=" + loginHelper.GetMacAddress()); 
        private System.Diagnostics.FileVersionInfo fv = System.Diagnostics.FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location);
        private bool _tipshown=false;
        private bool _tipgvshown=false;
             
        public string Tossigned
        {
            get;
            private set;
        }

        public ToS()
        {
            InitializeComponent();
            Dictionary<string, string> postParameters = new Dictionary<string, string>();
            webBrowser1.DocumentText = HTTP.HttpPostRequest(loginHelper.weburl + "ToSA.php?mac=" + loginHelper.GetMacAddress(), postParameters, "utf-8", fv);
        }

        public bool IsUserAdministrator()
        {
            bool isAdmin;
            try
            {
                WindowsIdentity user = WindowsIdentity.GetCurrent();
                WindowsPrincipal principal = new WindowsPrincipal(user);
                isAdmin = principal.IsInRole(WindowsBuiltInRole.Administrator);
            }
            catch (UnauthorizedAccessException ex)
            {
                isAdmin = false;
                System.Console.WriteLine(ex);
            }
            catch (Exception ex)
            {
                isAdmin = false;
                System.Console.WriteLine(ex);
            }
            return isAdmin;
        }

        private void btnAccept_Click(object sender, EventArgs e)
        {
            try
            {
                var fname = webBrowser1.Document.GetElementById("fname").GetAttribute("value");
                var lname = webBrowser1.Document.GetElementById("lname").GetAttribute("value");
                var email = webBrowser1.Document.GetElementById("email").GetAttribute("value");
                var vid = webBrowser1.Document.GetElementById("vid").GetAttribute("value");
                var vidv = webBrowser1.Document.GetElementById("vidv").GetAttribute("value");

                //var fname = (IHTMLInputElement)webBrowser1.Document.GetElementById("fname").DomElement;
                //var lname = (IHTMLInputElement)webBrowser1.Document.GetElementById("lname").DomElement;
                //var email = (IHTMLInputElement)webBrowser1.Document.GetElementById("email").DomElement;
                //var vid = (IHTMLInputElement)webBrowser1.Document.GetElementById("vid").DomElement;
                //var vidv = (IHTMLInputElement)webBrowser1.Document.GetElementById("vidv").DomElement;

                if (string.IsNullOrEmpty(fname))
                {
                    HtmlElement formElement = webBrowser1.Document.GetElementById("fname");
                    formElement.Style = "border: 1px solid red;";
                }
                if (string.IsNullOrEmpty(lname))
                {
                    HtmlElement formElement = webBrowser1.Document.GetElementById("lname");
                    formElement.Style = "border: 1px solid red;";
                }

                if (string.IsNullOrEmpty(email))
                {
                    HtmlElement formElement = webBrowser1.Document.GetElementById("email");
                    formElement.Style = "border: 1px solid red;";
                }

                if (string.IsNullOrEmpty(vid) && IsValidKey(vid))
                {
                    HtmlElement formElement = webBrowser1.Document.GetElementById("vid");
                    formElement.Style = "border: 1px solid red;";
                }
                if (!string.IsNullOrEmpty(vid) && !string.IsNullOrEmpty(vidv) && vid == vidv)
                {
                    if (!string.IsNullOrEmpty(fname))
                    {
                        if (!string.IsNullOrEmpty(lname))
                        {
                            if (!string.IsNullOrEmpty(email))
                            {
                                Dictionary<string, string> postParameters = new Dictionary<string, string>();
                                postParameters.Add("email", email);
                                postParameters.Add("mac", loginHelper.GetMacAddress());
                                postParameters.Add("fname", fname);
                                postParameters.Add("lname", lname);
                                try
                                {
                                    string html = HTTP.HttpPostRequest(loginHelper.weburl + "ToSaccept.php", postParameters, "utf-8", fv);//Encoding.UTF8.GetString(response);
                                    
                                    if (html == fv.FileVersion)
                                    {
                                        Tossigned = fv.FileVersion;
                                        this.DialogResult = DialogResult.OK;
                                    }
                                    //else
                                    //{
                                    //    MessageBox.Show(_rm.GetString("update") + " " + html, _rm.GetString("ServerError"), MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                                    //}
                                }
                                catch (Exception ex)
                                {
                                    System.Console.WriteLine("Button accept Click exception" + ex.Message.ToString());
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex.Message.ToString());
                //return;
            }
        }

        private void ToS_FormClosing(object sender, FormClosingEventArgs e)
        {
           
            if (Tossigned != fv.FileVersion)
            {
                Environment.Exit(0);
            }
            timer2.Stop();
            timer2.Dispose();
            timer1.Dispose();
        }

        private void ToS_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (Tossigned != fv.FileVersion)
            {
                Environment.Exit(0);
            }
            timer2.Stop();
            timer2.Dispose();
            timer1.Dispose();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                if (IsUserAdministrator() == false)
                {
                    HtmlElement formElement = webBrowser1.Document.GetElementById("isadmin");
                    formElement.Style = "Display:None;";
                    HtmlElement formElement1 = webBrowser1.Document.GetElementById("isnotadmin");
                    formElement1.Style = "Display:inline; border: 1px solid red;";
                }
                else
                {
                        HtmlElement formElement = webBrowser1.Document.GetElementById("isadmin");
                        formElement.Style = "Display:None;";
                        HtmlElement formElement1 = webBrowser1.Document.GetElementById("isnotadmin");
                        formElement1.Style = "Display:None;";
                }

                var email = this.webBrowser1.Document.GetElementById("email").GetAttribute("value");
                var fname = this.webBrowser1.Document.GetElementById("fname").GetAttribute("value");
                var lname = this.webBrowser1.Document.GetElementById("lname").GetAttribute("value");

                string vid = null;
                string vidv = null;
                try
                {
                    vid = webBrowser1.Document.GetElementById("vid").GetAttribute("value");
                    vidv = this.webBrowser1.Document.GetElementById("vidv").GetAttribute("value");
                }
                catch (Exception ex)
                {
                   
                }

                if (!string.IsNullOrEmpty(fname) && !string.IsNullOrEmpty(fname) && EmailCheck.IsValidEmail(email))
                {
                    if (!string.IsNullOrEmpty(vidv))
                    {
                        this.GetValidationID.Visible = false;
                    }
                    else {
                        this.GetValidationID.Visible = true;
                        if (_tipgvshown == true)
                        {
                            var sb = new StringBuilder();
                            _tip = new ToolTipOverride();
                            timer2.Start();
                            _lasttime = DateTime.Now.Ticks;
                            timer2.Enabled = true;
                            _tip.ToolTipIcon = ToolTipIcon.Info;
                            _tip.IsBalloon = true;
                            _tip.ToolTipTitle = "Get Verification ID";
                            Rectangle screenRectangle = RectangleToScreen(this.ClientRectangle);
                            int titleHeight = screenRectangle.Bottom - this.Bottom;
                            _tip.Show("You have filed out all info \r\n Please click the GET Verification ID\r\n", this, new Point(ClientRectangle.Left, GetValidationID.Top - (GetValidationID.Height + 25)));
                            _tipgvshown = true;
                        }
                        return;
                    }
                }
                
                if (!string.IsNullOrEmpty(vid) && vid.ToString().Length > 9 && IsValidKey(vid) && vid == vidv)
                {
                    this.btnAccept.Visible = true;
                    if (_tipshown == false)
                    {
                        var sb = new StringBuilder();
                        _tip = new ToolTipOverride();
                        timer2.Start();
                        _lasttime = DateTime.Now.Ticks;
                        timer2.Enabled = true;
                        _tip.ToolTipIcon = ToolTipIcon.Info;
                        _tip.IsBalloon = true;
                        _tip.ToolTipTitle = "Accept";
                        Rectangle screenRectangle = RectangleToScreen(this.ClientRectangle);
                        int titleHeight = screenRectangle.Top - this.Top;
                        _tip.Show("You have filed out all information\nPlease click the Accept button\n", this, new Point(ClientRectangle.Left, btnAccept.Top - (btnAccept.Height + 25)));
                        _tipshown = true;
                    }
                    return;
                }
            }
            catch (Exception ex)
            {
                System.Console.Write("Timer Tick Exception "+ ex.Message);
            }
            this.btnAccept.Visible = false;
            this.GetValidationID.Visible = false;
        }

        private bool IsValidKey(string vid)
        {
            if (vid == null) { return false; }
            string allowableLetters = "abcdef1234567890";
            foreach (char c in vid)
            {
                // This is using String.Contains for .NET 2 compat.,
                // hence the requirement for ToString()
                if (!allowableLetters.Contains(c.ToString()))
                    return false;
            }
            return true;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (new TimeSpan(DateTime.Now.Ticks - _lasttime).TotalMilliseconds > 3000)
            {
                _tip.Hide(this);
                timer2.Stop();
                timer2.Enabled = false;
            }
        }
        private void webBrowser1_Navigating(object sender, WebBrowserNavigatingEventArgs e)
        {
            if (e.Url.Scheme == "http")
            {
                var fname = webBrowser1.Document.GetElementById("fname").GetAttribute("value");
                var lname = webBrowser1.Document.GetElementById("lname").GetAttribute("value");
                var email = webBrowser1.Document.GetElementById("email").GetAttribute("value");

                e.Cancel = true;
                Dictionary<string, string> postParameters = new Dictionary<string, string>();
                postParameters.Add("email", email);
                postParameters.Add("mac", loginHelper.GetMacAddress());
                postParameters.Add("fname", fname);
                postParameters.Add("lname", lname);

                webBrowser1.DocumentText = HTTP.HttpPostRequest(e.Url.AbsoluteUri, postParameters, "utf-8", fv);
            }
            else
            {
                if (e.Url.AbsoluteUri == "about:ToSA.php#vidv")
                {
                    e.Cancel = true;
                }
                else
                {
                    e.Cancel = false;
                }
            }
        }

        private void GetValidationID_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                try
                {
                    var fname = webBrowser1.Document.GetElementById("fname").GetAttribute("value");
                    var lname = webBrowser1.Document.GetElementById("lname").GetAttribute("value");
                    var email = webBrowser1.Document.GetElementById("email").GetAttribute("value");
                   
                    //var fname = (IHTMLInputElement)webBrowser1.Document.GetElementById("fname").DomElement;
                    //var lname = (IHTMLInputElement)webBrowser1.Document.GetElementById("lname").DomElement;
                    //var email = (IHTMLInputElement)webBrowser1.Document.GetElementById("email").DomElement;

                    if (string.IsNullOrEmpty(fname))
                    {
                        HtmlElement formElement = webBrowser1.Document.GetElementById("fname");
                        formElement.Style = "border: 1px solid red;";
                    }
                    if (string.IsNullOrEmpty(lname))
                    {
                        HtmlElement formElement = webBrowser1.Document.GetElementById("lname");
                        formElement.Style = "border: 1px solid red;";
                    }

                    if (!D3.Ui.EmailCheck.IsValidEmail(email.ToString()))
                    {
                        HtmlElement formElement = webBrowser1.Document.GetElementById("email");
                        formElement.Style = "border: 1px solid red;";
                    }

                   
                    if (D3.Ui.EmailCheck.IsValidEmail(email.ToString()))
                    {
                        if (!string.IsNullOrEmpty(fname))
                        {
                            if (!string.IsNullOrEmpty(lname))
                            {
                                if (!string.IsNullOrEmpty(email))
                                {
                                    Dictionary<string, string> postParameters = new Dictionary<string, string>();
                                    postParameters.Add("email", email);
                                    postParameters.Add("mac", loginHelper.GetMacAddress());
                                    postParameters.Add("fname", fname);
                                    postParameters.Add("lname", lname);
                                    try
                                    {
                                        webBrowser1.DocumentText = HTTP.HttpPostRequest(loginHelper.weburl + "ToSA.php", postParameters, "utf-8", fv);

                                        webBrowser1.Url = _uri;
                                    }
                                    catch (Exception ex)
                                    {
                                        System.Console.WriteLine("Button accept Click exception" + ex.Message.ToString());
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Console.WriteLine(ex.Message.ToString());
                    //return;
                }
            }
        }

        private void btnAccept_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            { 

            }
        }

        private void webBrowser1_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                //menuItem.PerformClick();
                Dictionary<string, string> postParameters = new Dictionary<string, string>();
                webBrowser1.DocumentText = HTTP.HttpPostRequest(loginHelper.weburl + "ToSA.php?mac=" + loginHelper.GetMacAddress(), postParameters, "utf-8", fv);
                return;
            }
        }   
    }
}
