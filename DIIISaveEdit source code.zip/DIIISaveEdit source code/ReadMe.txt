Copyright Disclaimer Under Section 107 of the Copyright Act 1976,
allowance is made for "fair use" for purposes such as criticism, comment, news reporting, teaching, 
scholarship, and research. Fair use is a use permitted by copyright statute that might otherwise be 
infringing. Non-profit, educational or personal use tips the balance in favor of fair use.

    Copyright � 2013 - 2017 AWP ENT LLC (xx_CKY_xx at hotmail dot com)
  
   This(software is provided) 'as-is', without any express or implied
   warranty. Under no circumstances will the authors be held liable for any damages encountered 
   from the use of this software.
  
   Permission is granted to anyone to use this software for any purpose
   excluding commercial applications, or to alter it and redistribute it
   freely, subject to the following restrictions:
  
   1. The origin of this software must not be misrepresented; you must not
     claim that you wrote the original software. If you use this software
     in a product, an acknowledgment in the product documentation is required.
  
   2. Altered source versions must be plainly marked as such, and must not
      be misrepresented as being the original software.
  
   3. This notice may not be removed or altered from any source distribution in any way.
  
All material here in is copyright and trademarked to there respective owners.

